"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.z_TxEnvelopeTempo = exports.z_SignatureEnvelope = exports.z_KeyAuthorization = exports.AddressMismatchError = void 0;
exports.deserialize = deserialize;
exports.from = from;
exports.fromHeadlessWebAuthn = fromHeadlessWebAuthn;
exports.fromP256 = fromP256;
exports.fromSecp256k1 = fromSecp256k1;
exports.fromConfig = fromConfig;
exports.fromWebAuthnP256 = fromWebAuthnP256;
exports.fromWebCryptoP256 = fromWebCryptoP256;
exports.signVoucher = signVoucher;
exports.getKeyAuthorizationSignPayload = getKeyAuthorizationSignPayload;
exports.signKeyAuthorization = signKeyAuthorization;
exports.resolveAccessKey = resolveAccessKey;
exports.serialize = serialize;
const Address = require("ox/Address");
const Hex = require("ox/Hex");
const P256 = require("ox/P256");
const PublicKey = require("ox/PublicKey");
const Secp256k1 = require("ox/Secp256k1");
const Signature = require("ox/Signature");
const tempo_1 = require("ox/tempo");
const WebAuthnP256 = require("ox/WebAuthnP256");
const WebCryptoP256 = require("ox/WebCryptoP256");
const parseAccount_js_1 = require("../accounts/utils/parseAccount.js");
const base_js_1 = require("../errors/base.js");
const hashAuthorization_js_1 = require("../utils/authorization/hashAuthorization.js");
const keccak256_js_1 = require("../utils/hash/keccak256.js");
const hashMessage_js_1 = require("../utils/signature/hashMessage.js");
const hashTypedData_js_1 = require("../utils/signature/hashTypedData.js");
const Signature_js_1 = require("./accounts/Signature.js");
const Transaction = require("./Transaction.js");
function deserialize(value, options = {}) {
    const { address, config } = value;
    const { credentials = [], getFn } = options;
    if (!config)
        return fromConfig(address);
    const owners = config.owners.map(({ owner, weight }) => {
        const credential = credentials.find((credential) => Address.isEqual(Address.fromPublicKey(PublicKey.fromHex(credential.publicKey)), owner));
        if (!credential)
            return { owner, weight };
        const { rpId } = credential;
        return { owner: fromWebAuthnP256(credential, { getFn, rpId }), weight };
    });
    const { salt, threshold } = config;
    const version = BigInt(config.version);
    const account = version === 0n
        ? fromConfig({ owners, salt, threshold })
        : fromConfig({ address, owners, salt, threshold, version });
    if (!Address.isEqual(account.address, address))
        throw new AddressMismatchError({ address, derived: account.address });
    return account;
}
function from(parameters) {
    const { access } = parameters;
    if (access)
        return fromAccessKey(parameters);
    return fromRoot(parameters);
}
function fromHeadlessWebAuthn(privateKey, options) {
    const { access, keyAuthorization, keyAuthorizationManager, rpId, origin, internal_version, } = options;
    const publicKey = P256.getPublicKey({ privateKey });
    return from({
        ...(access ? { access, keyAuthorization, keyAuthorizationManager } : {}),
        internal_version,
        keyType: 'webAuthn',
        publicKey,
        async sign({ hash }) {
            const { metadata, payload } = WebAuthnP256.getSignPayload({
                ...options,
                challenge: hash,
                rpId,
                origin,
            });
            const signature = P256.sign({
                payload,
                privateKey,
                hash: true,
            });
            return tempo_1.SignatureEnvelope.serialize({
                metadata,
                signature,
                publicKey,
                type: 'webAuthn',
            });
        },
    });
}
function fromP256(privateKey, options = {}) {
    const { access, keyAuthorization, keyAuthorizationManager, internal_version, } = options;
    const publicKey = P256.getPublicKey({ privateKey });
    return from({
        ...(access ? { access, keyAuthorization, keyAuthorizationManager } : {}),
        internal_version,
        keyType: 'p256',
        publicKey,
        async sign({ hash }) {
            const signature = P256.sign({ payload: hash, privateKey });
            return tempo_1.SignatureEnvelope.serialize({
                signature,
                publicKey,
                type: 'p256',
            });
        },
    });
}
function fromSecp256k1(privateKey, options = {}) {
    const { access, keyAuthorization, keyAuthorizationManager, internal_version, } = options;
    const publicKey = Secp256k1.getPublicKey({ privateKey });
    return from({
        ...(access ? { access, keyAuthorization, keyAuthorizationManager } : {}),
        internal_version,
        keyType: 'secp256k1',
        publicKey,
        async sign(parameters) {
            const { hash } = parameters;
            const signature = Secp256k1.sign({ payload: hash, privateKey });
            return Signature.toHex(signature);
        },
    });
}
function fromConfig(value, options = {}) {
    const configInput = (() => {
        if (typeof value === 'string')
            return undefined;
        if ('upgrade' in value)
            return value.upgrade;
        const { address: _, ...config } = value;
        return config;
    })();
    const config = (() => {
        if (!configInput)
            return undefined;
        const ownerEntries = configInput.owners.map((value) => typeof value === 'string' || 'address' in value
            ? { owner: value, weight: 1 }
            : value);
        const owners = ownerEntries.map(({ owner, weight }) => ({
            owner: typeof owner === 'string' ? owner : owner.address,
            weight,
        }));
        const threshold = configInput.threshold ?? 1;
        if (typeof value !== 'string' && 'upgrade' in value)
            return tempo_1.AccountConfig.fromUpgrade(value.address, { owners, threshold });
        return tempo_1.AccountConfig.from({ ...configInput, owners, threshold });
    })();
    if (typeof value !== 'string' && !('upgrade' in value)) {
        if ((value.address === undefined || value.address === 'infer') &&
            config.version !== 0n)
            throw new Error('An initial account config must have version zero.');
        if (value.address !== undefined &&
            value.address !== 'infer' &&
            config.version === 0n)
            throw new Error('A current account config must have a version.');
    }
    const address = Address.checksum((() => {
        if (typeof value === 'string')
            return value;
        if (value.address === undefined || value.address === 'infer')
            return tempo_1.AccountConfig.getAddress(config);
        return value.address;
    })());
    const ownerAccounts = (() => {
        if (!configInput)
            return [];
        return configInput.owners.flatMap((value) => {
            const owner = typeof value === 'string' || 'address' in value ? value : value.owner;
            return typeof owner === 'string' ? [] : [(0, parseAccount_js_1.parseAccount)(owner)];
        });
    })();
    if (ownerAccounts.some((owner) => owner.source === 'configurable' || isAccessKeyAccount(owner)))
        throw new Error('Configurable account owners must use primitive signatures.');
    const owners = config?.owners.flatMap(({ owner }) => {
        const account = ownerAccounts.find((account) => Address.isEqual(account.address, owner));
        return account ? [account] : [];
    }) ?? [];
    const account = {
        address,
        config,
        owners,
        publicKey: '0x',
        source: 'configurable',
        type: 'local',
        async sign({ hash }) {
            return tempo_1.SignatureEnvelope.serialize(await signConfigurable(account, { payload: hash }));
        },
        async signMessage({ message }) {
            return await account.sign({ hash: (0, hashMessage_js_1.hashMessage)(message) });
        },
        async signTransaction(transaction, options) {
            const { serializer = Transaction.serialize } = options ?? {};
            const request = transaction;
            if (request.owner) {
                const owner = (0, parseAccount_js_1.parseAccount)(request.owner);
                if (owner.type !== 'local')
                    throw new Error('A local owner account is required to approve a configurable account transaction.');
                if (owner.source !== 'root')
                    throw new Error('A Tempo owner account is required to approve a configurable account transaction.');
                const { owner: _, ...ownerRequest } = request;
                return await owner.signTransaction(ownerRequest, options);
            }
            if (owners.length === 0)
                return (await serializer(transaction));
            const presign = {
                ...request,
                signatures: undefined,
                ...(request.feePayerSignature === undefined
                    ? {}
                    : { feePayerSignature: null }),
            };
            const payload = (0, keccak256_js_1.keccak256)(await serializer(presign));
            const simulation = request.accountSimulation;
            if (request.from && !Address.isEqual(request.from, address))
                throw new Error('Configurable account does not match the transaction sender.');
            const signature = await signConfigurable(account, {
                config: simulation?.config,
                payload,
                signatures: request.signatures?.map((signature) => (0, Signature_js_1.parseApproval)(signature)),
            });
            return (await serializer(transaction, signature));
        },
        async signTypedData(typedData) {
            return await account.sign({ hash: (0, hashTypedData_js_1.hashTypedData)(typedData) });
        },
    };
    if (options.access)
        return toAccessKey(account, { ...options, access: options.access });
    return account;
}
function toAccessKey(account, options) {
    const { access, keyAuthorization } = options;
    const { address: parentAddress } = (0, parseAccount_js_1.parseAccount)(access);
    const accessKeyAddress = account.address;
    if (Address.isEqual(parentAddress, accessKeyAddress))
        throw new Error('A configurable account cannot be its own access key.');
    if (keyAuthorization &&
        (keyAuthorization.type !== 'configurable' ||
            !Address.isEqual(keyAuthorization.address, accessKeyAddress)))
        throw new Error('Key authorization does not authorize this access key.');
    const keyAuthorizationManager = options.keyAuthorizationManager ??
        (keyAuthorization ? pending(keyAuthorization) : undefined);
    async function sign(parameters) {
        const { hash, raw } = parameters;
        if (raw)
            return await account.sign({ hash });
        const inner = await signConfigurable(account, {
            payload: (0, keccak256_js_1.keccak256)(Hex.concat('0x04', hash, parentAddress)),
        });
        return tempo_1.SignatureEnvelope.serialize(tempo_1.SignatureEnvelope.from({
            inner,
            type: 'keychain',
            userAddress: parentAddress,
            version: 'v2',
        }));
    }
    return {
        accessKeyAddress,
        address: Address.checksum(parentAddress),
        delegate: account,
        keyAuthorizationManager,
        keyType: 'configurable',
        publicKey: '0x',
        sign,
        async signAuthorization() {
            throw new Error('A configurable access key cannot sign authorizations.');
        },
        async signMessage({ message }) {
            return await sign({ hash: (0, hashMessage_js_1.hashMessage)(message) });
        },
        async signTransaction(transaction, options) {
            const { serializer = Transaction.serialize } = options ?? {};
            const request = transaction;
            if (request.owner) {
                const owner = (0, parseAccount_js_1.parseAccount)(request.owner);
                if (owner.type !== 'local')
                    throw new Error('A local owner account is required to approve a configurable account transaction.');
                if (owner.source !== 'root')
                    throw new Error('A Tempo owner account is required to approve a configurable account transaction.');
                const { owner: _, ...ownerRequest } = request;
                return await owner.signTransaction(ownerRequest, options);
            }
            if (request.from && !Address.isEqual(request.from, parentAddress))
                throw new Error('Access key account does not match the transaction sender.');
            if (account.owners.length === 0)
                return (await serializer(transaction));
            const presign = {
                ...request,
                signatures: undefined,
                ...(request.feePayerSignature === undefined
                    ? {}
                    : { feePayerSignature: null }),
            };
            const payload = (0, keccak256_js_1.keccak256)(await serializer(presign));
            const inner = await signConfigurable(account, {
                config: request.accountSimulation?.config,
                payload: (0, keccak256_js_1.keccak256)(Hex.concat('0x04', payload, parentAddress)),
                signatures: request.signatures?.map((signature) => (0, Signature_js_1.parseApproval)(signature)),
            });
            const signature = tempo_1.SignatureEnvelope.from({
                inner,
                type: 'keychain',
                userAddress: parentAddress,
                version: 'v2',
            });
            return (await serializer(transaction, signature));
        },
        async signTypedData(typedData) {
            return await sign({ hash: (0, hashTypedData_js_1.hashTypedData)(typedData) });
        },
        async signVoucher(parameters) {
            return await sign({ hash: getVoucherSignPayload(parameters), raw: true });
        },
        source: 'accessKey',
        type: 'local',
    };
}
function isConfigurableAccount(account) {
    return account.source === 'configurable';
}
async function signConfigurable(account, parameters) {
    const { config, payload, signatures: providedSignatures = [] } = parameters;
    const currentConfig = config ?? account.config;
    if (!currentConfig)
        throw new Error('A current account config is required for local signing.');
    const digest = tempo_1.AccountConfig.getSignPayload({
        account: account.address,
        config: currentConfig,
        payload,
    });
    const signatures = [...providedSignatures];
    const signedOwners = new Set();
    let weight = 0;
    for (const signature of providedSignatures) {
        const address = tempo_1.SignatureEnvelope.extractAddress({
            payload: digest,
            signature,
        }).toLowerCase();
        const owner = currentConfig.owners.find((owner) => Address.isEqual(owner.owner, address));
        if (!owner || signedOwners.has(address))
            continue;
        signedOwners.add(address);
        weight += Number(owner.weight);
    }
    const owners = [...currentConfig.owners].sort((a, b) => Number(b.weight) - Number(a.weight) ||
        a.owner.toLowerCase().localeCompare(b.owner.toLowerCase()));
    for (const owner of owners) {
        if (weight >= Number(currentConfig.threshold))
            break;
        const address = owner.owner.toLowerCase();
        if (signedOwners.has(address))
            continue;
        const ownerAccount = account.owners.find((account) => Address.isEqual(account.address, owner.owner));
        if (!ownerAccount)
            continue;
        if (!ownerAccount.sign)
            throw new Error('Configurable account owner account cannot sign.');
        signatures.push((0, Signature_js_1.parseApproval)(await ownerAccount.sign({ hash: digest })));
        signedOwners.add(address);
        weight += Number(owner.weight);
        if (weight >= Number(currentConfig.threshold))
            break;
    }
    if (weight < Number(currentConfig.threshold))
        throw new Error('Local owners do not meet the threshold.');
    return tempo_1.SignatureEnvelope.from({
        account: account.address,
        config: currentConfig,
        signatures: tempo_1.SignatureEnvelope.sortApprovals({
            account: account.address,
            config: currentConfig,
            payload,
            signatures,
        }),
    });
}
function fromWebAuthnP256(credential, options = {}) {
    const { id } = credential;
    const publicKey = PublicKey.fromHex(credential.publicKey);
    return from({
        keyType: 'webAuthn',
        publicKey,
        async sign({ hash }) {
            const { metadata, signature } = await WebAuthnP256.sign({
                ...options,
                challenge: hash,
                credentialId: id,
            });
            return tempo_1.SignatureEnvelope.serialize({
                publicKey,
                metadata,
                signature,
                type: 'webAuthn',
            });
        },
    });
}
function fromWebCryptoP256(keyPair, options = {}) {
    const { access, keyAuthorization, keyAuthorizationManager, internal_version, } = options;
    const { publicKey, privateKey } = keyPair;
    return from({
        ...(access ? { access, keyAuthorization, keyAuthorizationManager } : {}),
        internal_version,
        keyType: 'p256',
        publicKey,
        async sign({ hash }) {
            const signature = await WebCryptoP256.sign({ payload: hash, privateKey });
            return tempo_1.SignatureEnvelope.serialize({
                signature,
                prehash: true,
                publicKey,
                type: 'p256',
            });
        },
    });
}
async function signVoucher(account, parameters) {
    const hash = getVoucherSignPayload(parameters);
    if (isAccessKeyAccount(account))
        return account.sign({ hash, raw: true });
    return account.sign({ hash });
}
function getVoucherSignPayload(parameters) {
    const { chainId, channel, cumulativeAmount } = parameters;
    const channelId = typeof channel === 'string'
        ? channel
        : tempo_1.Channel.computeId(channel, {
            chainId,
        });
    return tempo_1.Channel.getVoucherSignPayload({
        chainId,
        channelId,
        cumulativeAmount,
    });
}
function isAccessKeyAccount(account) {
    return account.source === 'accessKey' && 'accessKeyAddress' in account;
}
function getKeyAuthorizationSignPayload(account, parameters) {
    const { chainId, expiry, key, limits, scopes, witness } = parameters;
    const { accessKeyAddress, keyType: type } = resolveAccessKey(key);
    if (isAccessKeyAccount(account))
        throw new Error('An access key cannot sign key authorizations.');
    const boundFields = isConfigurableAccount(account)
        ? { account: account.address }
        : {};
    return tempo_1.KeyAuthorization.getSignPayload({
        address: accessKeyAddress,
        chainId,
        expiry,
        limits,
        scopes,
        type,
        witness,
        ...boundFields,
    });
}
async function signKeyAuthorization(account, parameters) {
    const { chainId, expiry, key, limits, configurable: configurableState, scopes, signatures, witness, } = parameters;
    const { accessKeyAddress, keyType: type } = resolveAccessKey(key);
    const isConfigurable = isConfigurableAccount(account);
    const boundFields = isConfigurable ? { account: account.address } : {};
    const hash = getKeyAuthorizationSignPayload(account, parameters);
    const signature = await (async () => {
        if (isConfigurable) {
            if (!configurableState)
                throw new Error('Configurable account state is required to sign a key authorization.');
            return tempo_1.SignatureEnvelope.serialize(await signConfigurable(account, {
                config: configurableState.config,
                payload: hash,
                signatures: signatures?.map((signature) => (0, Signature_js_1.parseApproval)(signature)),
            }));
        }
        return account.sign({ hash });
    })();
    return tempo_1.KeyAuthorization.from({
        address: accessKeyAddress,
        chainId,
        expiry,
        limits,
        scopes,
        signature: tempo_1.SignatureEnvelope.from(signature),
        type,
        ...(witness ? { witness } : {}),
        ...boundFields,
    });
}
function fromBase(parameters) {
    const { keyType = 'secp256k1', parentAddress, source = 'privateKey', internal_version = 'v2', } = parameters;
    const address = parentAddress ?? Address.fromPublicKey(parameters.publicKey);
    const publicKey = PublicKey.toHex(parameters.publicKey, {
        includePrefix: false,
    });
    async function sign({ hash, raw }) {
        if (raw)
            return await parameters.sign({ hash });
        const innerHash = parentAddress && internal_version === 'v2'
            ? (0, keccak256_js_1.keccak256)(Hex.concat('0x04', hash, parentAddress))
            : hash;
        const signature = await parameters.sign({ hash: innerHash });
        if (parentAddress)
            return tempo_1.SignatureEnvelope.serialize(tempo_1.SignatureEnvelope.from({
                userAddress: parentAddress,
                inner: tempo_1.SignatureEnvelope.from(signature),
                type: 'keychain',
                version: internal_version,
            }));
        return signature;
    }
    return {
        address: Address.checksum(address),
        keyType,
        sign,
        async signAuthorization(parameters) {
            const { chainId, nonce } = parameters;
            const address = parameters.contractAddress ?? parameters.address;
            const signature = await sign({
                hash: (0, hashAuthorization_js_1.hashAuthorization)({ address, chainId, nonce }),
            });
            const envelope = tempo_1.SignatureEnvelope.from(signature);
            if (envelope.type !== 'secp256k1')
                throw new Error('Unsupported signature type. Expected `secp256k1` but got `' +
                    envelope.type +
                    '`.');
            const { r, s, yParity } = envelope.signature;
            return {
                address,
                chainId,
                nonce,
                r: Hex.fromNumber(r, { size: 32 }),
                s: Hex.fromNumber(s, { size: 32 }),
                yParity,
            };
        },
        async signMessage(parameters) {
            const { message } = parameters;
            return await sign({ hash: (0, hashMessage_js_1.hashMessage)(message) });
        },
        async signTransaction(transaction, options) {
            const { serializer = Transaction.serialize } = options ?? {};
            const presign = (() => {
                if ('feePayerSignature' in transaction && transaction.feePayerSignature)
                    return { ...transaction, feePayerSignature: null };
                return transaction;
            })();
            const payload = (0, keccak256_js_1.keccak256)(await serializer(presign));
            const { accountSimulation, from } = transaction;
            if (accountSimulation) {
                if (!from)
                    throw new Error('A configurable account sender is required for signing.');
                const config = tempo_1.AccountConfig.from(accountSimulation.config);
                const { signer = from } = accountSimulation;
                const digest = tempo_1.AccountConfig.getSignPayload({
                    account: signer,
                    config,
                    payload: Address.isEqual(signer, from)
                        ? payload
                        : (0, keccak256_js_1.keccak256)(Hex.concat('0x04', payload, from)),
                });
                return await sign({ hash: digest, raw: true });
            }
            const signature = await sign({ hash: payload });
            const envelope = tempo_1.SignatureEnvelope.from(signature);
            return await serializer(transaction, envelope);
        },
        async signTypedData(typedData) {
            return await sign({ hash: (0, hashTypedData_js_1.hashTypedData)(typedData) });
        },
        async signVoucher(parameters) {
            const hash = getVoucherSignPayload(parameters);
            if (parentAddress)
                return await sign({ hash, raw: true });
            return await sign({ hash });
        },
        publicKey,
        source,
        type: 'local',
    };
}
function fromRoot(parameters) {
    const account = fromBase(parameters);
    return {
        ...account,
        source: 'root',
        async signKeyAuthorization(key, parameters) {
            const { chainId, expiry, limits, scopes, witness } = parameters;
            const { accessKeyAddress, keyType: type } = resolveAccessKey(key);
            const signature = await account.sign({
                hash: tempo_1.KeyAuthorization.getSignPayload({
                    address: accessKeyAddress,
                    chainId,
                    expiry,
                    limits,
                    scopes,
                    type,
                    witness,
                }),
            });
            return tempo_1.KeyAuthorization.from({
                address: accessKeyAddress,
                chainId,
                expiry,
                limits,
                scopes,
                signature: tempo_1.SignatureEnvelope.from(signature),
                type,
                ...(witness ? { witness } : {}),
            });
        },
    };
}
function fromAccessKey(parameters) {
    const { access, keyAuthorization } = parameters;
    const { address: parentAddress } = (0, parseAccount_js_1.parseAccount)(access);
    const accessKeyAddress = Address.fromPublicKey(parameters.publicKey);
    if (keyAuthorization &&
        !Address.isEqual(keyAuthorization.address, accessKeyAddress))
        throw new Error('Key authorization does not authorize this access key.');
    const keyAuthorizationManager = parameters.keyAuthorizationManager ??
        (keyAuthorization ? pending(keyAuthorization) : undefined);
    const account = fromBase({
        ...parameters,
        keyAuthorizationManager,
        parentAddress,
    });
    async function preAuthorize(signature) {
        const { internal_version = 'v2' } = parameters;
        if (!keyAuthorization || !keyAuthorizationManager)
            return signature;
        if (internal_version !== 'v2')
            return signature;
        const pending = await keyAuthorizationManager.get({
            address: account.address,
            accessKey: accessKeyAddress,
            chainId: Number(keyAuthorization.chainId),
        });
        if (!pending)
            return signature;
        return tempo_1.SignaturePreAuthorized.wrap({
            keyAuthorization: pending,
            signature: tempo_1.SignatureEnvelope.from(signature),
        });
    }
    return {
        ...account,
        accessKeyAddress,
        keyAuthorizationManager,
        async sign(parameters) {
            const signature = await account.sign(parameters);
            if (parameters.raw)
                return signature;
            return await preAuthorize(signature);
        },
        async signMessage(parameters) {
            return await preAuthorize(await account.signMessage(parameters));
        },
        async signTypedData(typedData) {
            return await preAuthorize(await account.signTypedData(typedData));
        },
        source: 'accessKey',
    };
}
function pending(keyAuthorization) {
    let value = keyAuthorization;
    const matches = (key) => Address.isEqual(key.accessKey, keyAuthorization.address) &&
        BigInt(key.chainId) === BigInt(keyAuthorization.chainId);
    return {
        get: (key) => (matches(key) ? value : undefined),
        remove(key) {
            if (matches(key))
                value = undefined;
        },
        set(key, next) {
            if (matches(key))
                value = next;
        },
    };
}
function resolveAccessKey(accessKey) {
    if ('accessKeyAddress' in accessKey)
        return {
            accessKeyAddress: accessKey.accessKeyAddress,
            keyType: accessKey.keyType,
        };
    if ('publicKey' in accessKey && accessKey.publicKey)
        return {
            accessKeyAddress: Address.fromPublicKey(PublicKey.fromHex(accessKey.publicKey)),
            keyType: accessKey.type,
        };
    return {
        accessKeyAddress: accessKey.address,
        keyType: accessKey.type,
    };
}
function serialize(account) {
    const { address, config } = account;
    return {
        address,
        ...(config ? { config: tempo_1.AccountConfig.toRpc(config) } : {}),
    };
}
class AddressMismatchError extends base_js_1.BaseError {
    constructor(options) {
        const { address, derived } = options;
        super(`Account config derives ${derived}, not ${address}.`, {
            name: 'Account.AddressMismatchError',
        });
        Object.defineProperty(this, "derived", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.derived = derived;
    }
}
exports.AddressMismatchError = AddressMismatchError;
var tempo_2 = require("ox/tempo");
Object.defineProperty(exports, "z_KeyAuthorization", { enumerable: true, get: function () { return tempo_2.KeyAuthorization; } });
Object.defineProperty(exports, "z_SignatureEnvelope", { enumerable: true, get: function () { return tempo_2.SignatureEnvelope; } });
Object.defineProperty(exports, "z_TxEnvelopeTempo", { enumerable: true, get: function () { return tempo_2.TxEnvelopeTempo; } });
//# sourceMappingURL=Account.js.map