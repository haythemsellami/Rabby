"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorResolvers = exports.AccessKeyExpiryInPastError = exports.AccessKeySignatureTypeMismatchError = exports.AccessKeyAlreadyExistsError = exports.AccessKeyCallNotAllowedError = exports.AccessKeyExpiredError = exports.AccessKeySpendingLimitExceededError = exports.AccessKeyError = void 0;
exports.authorize = authorize;
exports.authorizeSync = authorizeSync;
exports.burnWitness = burnWitness;
exports.burnWitnessSync = burnWitnessSync;
exports.getMetadata = getMetadata;
exports.getRemainingLimit = getRemainingLimit;
exports.isWitnessBurned = isWitnessBurned;
exports.revoke = revoke;
exports.revokeSync = revokeSync;
exports.prepareAuthorization = prepareAuthorization;
exports.saveAuthorization = saveAuthorization;
exports.signAuthorization = signAuthorization;
exports.updateLimit = updateLimit;
exports.updateLimitSync = updateLimitSync;
exports.watchWitness = watchWitness;
exports.watchWitnessBurned = watchWitnessBurned;
exports.verifyHash = verifyHash;
const tempo_1 = require("ox/tempo");
const parseAccount_js_1 = require("../../accounts/utils/parseAccount.js");
const readContract_js_1 = require("../../actions/public/readContract.js");
const watchContractEvent_js_1 = require("../../actions/public/watchContractEvent.js");
const sendTransaction_js_1 = require("../../actions/wallet/sendTransaction.js");
const sendTransactionSync_js_1 = require("../../actions/wallet/sendTransactionSync.js");
const writeContract_js_1 = require("../../actions/wallet/writeContract.js");
const writeContractSync_js_1 = require("../../actions/wallet/writeContractSync.js");
const rpc_js_1 = require("../../errors/rpc.js");
const formatAbiItem_js_1 = require("../../utils/abi/formatAbiItem.js");
const parseEventLogs_js_1 = require("../../utils/abi/parseEventLogs.js");
const isAddressEqual_js_1 = require("../../utils/address/isAddressEqual.js");
const Abis = require("../Abis.js");
const Account_js_1 = require("../Account.js");
const Addresses = require("../Addresses.js");
const Signature_js_1 = require("../accounts/Signature.js");
const errors_js_1 = require("../errors.js");
const Hardfork = require("../Hardfork.js");
const errors_js_2 = require("../internal/errors.js");
const utils_js_1 = require("../internal/utils.js");
const accounts_js_1 = require("./accounts.js");
const signatureTypes = {
    0: 'secp256k1',
    1: 'p256',
    2: 'webAuthn',
    3: 'configurable',
};
const spendPolicies = {
    true: 'limited',
    false: 'unlimited',
};
async function authorize(client, parameters) {
    return authorize.inner(sendTransaction_js_1.sendTransaction, client, parameters);
}
(function (authorize) {
    async function inner(action, client, parameters) {
        const { accessKey, chainId = client.chain?.id, expiry, limits, scopes, witness, ...rest } = parameters;
        const { account: account_ = client.account } = rest;
        if (!account_)
            throw new Error('account is required.');
        if (!chainId)
            throw new Error('chainId is required.');
        const keyAuthorization = await signLocal(client, {
            account: account_,
            accessKey,
            chainId,
            expiry,
            limits,
            scopes,
            witness,
        });
        return (await (0, errors_js_2.withExecutionError)(action, {
            hints: {
                KeyAlreadyExists: [
                    'This access key is already authorized. Update its spending limits instead.',
                ],
            },
        })(client, {
            ...rest,
            keyAuthorization,
        }));
    }
    authorize.inner = inner;
    function extractEvent(logs) {
        const [log] = (0, parseEventLogs_js_1.parseEventLogs)({
            abi: Abis.accountKeychain,
            logs,
            eventName: 'KeyAuthorized',
            strict: true,
        });
        if (!log)
            throw new Error('`KeyAuthorized` event not found.');
        return log;
    }
    authorize.extractEvent = extractEvent;
})(authorize || (exports.authorize = authorize = {}));
async function authorizeSync(client, parameters) {
    const { throwOnReceiptRevert = true, ...rest } = parameters;
    const receipt = await authorize.inner(sendTransactionSync_js_1.sendTransactionSync, client, {
        ...rest,
        throwOnReceiptRevert,
    });
    if (receipt.status === 'pending')
        return { receipt };
    const { args } = authorize.extractEvent(receipt.logs);
    return {
        ...args,
        receipt,
    };
}
async function burnWitness(client, parameters) {
    return burnWitness.inner(writeContract_js_1.writeContract, client, parameters);
}
(function (burnWitness) {
    async function inner(action, client, parameters) {
        const { witness, ...rest } = parameters;
        const call = burnWitness.call({ witness });
        return (await (0, errors_js_2.withExecutionError)(action)(client, {
            ...rest,
            ...call,
        }));
    }
    burnWitness.inner = inner;
    function call(args) {
        const { witness } = args;
        return (0, utils_js_1.defineCall)({
            address: Addresses.accountKeychain,
            abi: Abis.accountKeychain,
            functionName: 'burnKeyAuthorizationWitness',
            args: [witness],
        });
    }
    Object.defineProperty(burnWitness, "call", { configurable: true, enumerable: true, value: call, writable: true });
    function extractEvent(logs) {
        const [log] = (0, parseEventLogs_js_1.parseEventLogs)({
            abi: Abis.accountKeychain,
            logs,
            eventName: 'KeyAuthorizationWitnessBurned',
            strict: true,
        });
        if (!log)
            throw new Error('`KeyAuthorizationWitnessBurned` event not found.');
        return log;
    }
    burnWitness.extractEvent = extractEvent;
})(burnWitness || (exports.burnWitness = burnWitness = {}));
async function burnWitnessSync(client, parameters) {
    const { throwOnReceiptRevert = true, ...rest } = parameters;
    const receipt = await burnWitness.inner(writeContractSync_js_1.writeContractSync, client, {
        ...rest,
        throwOnReceiptRevert,
    });
    if (receipt.status === 'pending')
        return { receipt };
    const { args } = burnWitness.extractEvent(receipt.logs);
    return {
        ...args,
        receipt,
    };
}
async function getMetadata(client, parameters) {
    const { account: account_ = client.account, accessKey, ...rest } = parameters;
    if (!account_)
        throw new Error('account is required.');
    const account = (0, parseAccount_js_1.parseAccount)(account_);
    const result = await (0, errors_js_2.withExecutionError)(readContract_js_1.readContract)(client, {
        ...rest,
        account: null,
        ...getMetadata.call({ account: account.address, accessKey }),
    });
    return {
        address: result.keyId,
        keyType: signatureTypes[result.signatureType] ??
            'secp256k1',
        expiry: result.expiry,
        spendPolicy: spendPolicies[`${result.enforceLimits}`],
        isRevoked: result.isRevoked,
    };
}
(function (getMetadata) {
    function call(args) {
        const { account, accessKey } = args;
        return (0, utils_js_1.defineCall)({
            address: Addresses.accountKeychain,
            abi: Abis.accountKeychain,
            functionName: 'getKey',
            args: [account, resolveAccessKeyAddress(accessKey)],
        });
    }
    Object.defineProperty(getMetadata, "call", { configurable: true, enumerable: true, value: call, writable: true });
})(getMetadata || (exports.getMetadata = getMetadata = {}));
async function getRemainingLimit(client, parameters) {
    const { account: account_ = client.account, accessKey, token, ...rest } = parameters;
    if (!account_)
        throw new Error('account is required.');
    const account = (0, parseAccount_js_1.parseAccount)(account_);
    const hardfork = client.chain?.hardfork;
    if (hardfork && Hardfork.lt(hardfork, 't3')) {
        const remaining = await (0, errors_js_2.withExecutionError)(readContract_js_1.readContract)(client, {
            ...rest,
            ...getRemainingLimit.call({ account: account.address, accessKey, token }),
        });
        return { remaining, periodEnd: undefined };
    }
    const [remaining, periodEnd] = await (0, errors_js_2.withExecutionError)(readContract_js_1.readContract)(client, {
        ...rest,
        ...getRemainingLimit.callWithPeriod({
            account: account.address,
            accessKey,
            token,
        }),
    });
    return { remaining, periodEnd };
}
(function (getRemainingLimit) {
    function call(args) {
        const { account, accessKey, token } = args;
        return (0, utils_js_1.defineCall)({
            address: Addresses.accountKeychain,
            abi: Abis.accountKeychain,
            functionName: 'getRemainingLimit',
            args: [account, resolveAccessKeyAddress(accessKey), token],
        });
    }
    Object.defineProperty(getRemainingLimit, "call", { configurable: true, enumerable: true, value: call, writable: true });
    function callWithPeriod(args) {
        const { account, accessKey, token } = args;
        return (0, utils_js_1.defineCall)({
            address: Addresses.accountKeychain,
            abi: Abis.accountKeychain,
            functionName: 'getRemainingLimitWithPeriod',
            args: [account, resolveAccessKeyAddress(accessKey), token],
        });
    }
    getRemainingLimit.callWithPeriod = callWithPeriod;
})(getRemainingLimit || (exports.getRemainingLimit = getRemainingLimit = {}));
async function isWitnessBurned(client, parameters) {
    const { account: account_ = client.account, witness, ...rest } = parameters;
    if (!account_)
        throw new Error('account is required.');
    const account = (0, parseAccount_js_1.parseAccount)(account_);
    return (0, errors_js_2.withExecutionError)(readContract_js_1.readContract)(client, {
        ...rest,
        account: null,
        ...isWitnessBurned.call({ account: account.address, witness }),
    });
}
(function (isWitnessBurned) {
    function call(args) {
        const { account, witness } = args;
        return (0, utils_js_1.defineCall)({
            address: Addresses.accountKeychain,
            abi: Abis.accountKeychain,
            functionName: 'isKeyAuthorizationWitnessBurned',
            args: [account, witness],
        });
    }
    Object.defineProperty(isWitnessBurned, "call", { configurable: true, enumerable: true, value: call, writable: true });
})(isWitnessBurned || (exports.isWitnessBurned = isWitnessBurned = {}));
async function revoke(client, parameters) {
    return revoke.inner(writeContract_js_1.writeContract, client, parameters);
}
(function (revoke) {
    async function inner(action, client, parameters) {
        const { accessKey, ...rest } = parameters;
        const call = revoke.call({ accessKey });
        return (await (0, errors_js_2.withExecutionError)(action)(client, {
            ...rest,
            ...call,
        }));
    }
    revoke.inner = inner;
    function call(args) {
        const { accessKey } = args;
        return (0, utils_js_1.defineCall)({
            address: Addresses.accountKeychain,
            abi: Abis.accountKeychain,
            functionName: 'revokeKey',
            args: [resolveAccessKeyAddress(accessKey)],
        });
    }
    Object.defineProperty(revoke, "call", { configurable: true, enumerable: true, value: call, writable: true });
    function extractEvent(logs) {
        const [log] = (0, parseEventLogs_js_1.parseEventLogs)({
            abi: Abis.accountKeychain,
            logs,
            eventName: 'KeyRevoked',
            strict: true,
        });
        if (!log)
            throw new Error('`KeyRevoked` event not found.');
        return log;
    }
    revoke.extractEvent = extractEvent;
})(revoke || (exports.revoke = revoke = {}));
async function revokeSync(client, parameters) {
    const { throwOnReceiptRevert = true, ...rest } = parameters;
    const receipt = await revoke.inner(writeContractSync_js_1.writeContractSync, client, {
        ...rest,
        throwOnReceiptRevert,
    });
    if (receipt.status === 'pending')
        return { receipt };
    const { args } = revoke.extractEvent(receipt.logs);
    return {
        ...args,
        receipt,
    };
}
async function prepareAuthorization(client, parameters) {
    const { chainId = client.chain?.id } = parameters;
    const account_ = parameters.account ?? client.account;
    if (!account_)
        throw new Error('account is required.');
    if (!chainId)
        throw new Error('chainId is required.');
    const parsed = (0, parseAccount_js_1.parseAccount)(account_);
    const configurableState = await (async () => {
        if ('configurable' in parameters)
            return parameters.configurable;
        if (parsed.source !== 'configurable')
            return undefined;
        const account = parsed;
        if (!account.config)
            throw new Error('An account config is required to prepare a key authorization.');
        return { config: account.config };
    })();
    const authorizationSignPayload = (0, Account_js_1.getKeyAuthorizationSignPayload)(parsed, {
        ...parameters,
        chainId: BigInt(chainId),
        key: parameters.accessKey,
    });
    const signPayload = parsed.source === 'configurable' && configurableState
        ? tempo_1.AccountConfig.getSignPayload({
            account: parsed.address,
            config: configurableState.config,
            payload: authorizationSignPayload,
        })
        : authorizationSignPayload;
    return {
        ...parameters,
        account: parsed,
        chainId,
        configurable: configurableState,
        signPayload,
    };
}
async function saveAuthorization(client, parameters) {
    const { keyAuthorization } = parameters;
    await client.request({
        method: 'relay_saveKeyAuthorization',
        params: [tempo_1.KeyAuthorization.toRpc(keyAuthorization)],
    });
}
async function signAuthorization(client, parameters) {
    const coordinated = ('hash' in parameters && parameters.hash) ||
        ('owner' in parameters && parameters.owner);
    if (coordinated) {
        const parameters_ = parameters;
        const owner_ = parameters_.owner;
        if (!owner_ || typeof owner_ === 'string')
            throw new Error('A local owner account is required to approve a configurable account key authorization.');
        const owner = (0, parseAccount_js_1.parseAccount)(owner_);
        const sign = owner.sign;
        if (!sign)
            throw new Error('A local owner account is required to approve a configurable account key authorization.');
        const request = await (async () => {
            if ('hash' in parameters_ && parameters_.hash) {
                const signature = tempo_1.SignatureEnvelope.serialize(tempo_1.SignatureEnvelope.from(await sign({ hash: parameters_.hash })));
                return { hash: parameters_.hash, signature };
            }
            const { account: account_, owner: _, ...authorization } = parameters_;
            const address = typeof account_ === 'string' ? account_ : account_.address;
            const config = await (async () => {
                if (typeof account_ !== 'string' && account_.config)
                    return account_.config;
                const config = await (0, accounts_js_1.getConfig)(client, { address });
                if (config)
                    return config;
                throw new Error(`No current account config is cached for account ${address}. Provide the current config.`);
            })();
            const account = (() => {
                if (config.version !== 0n)
                    return (0, Account_js_1.fromConfig)({ address, ...config });
                const { version: _, ...initialConfig } = config;
                return (0, Account_js_1.fromConfig)({ address: 'infer', ...initialConfig });
            })();
            if (!(0, isAddressEqual_js_1.isAddressEqual)(account.address, address))
                throw new Error('Initial account config does not match the account.');
            const prepared = await prepareAuthorization(client, {
                ...authorization,
                account,
            });
            const signature = tempo_1.SignatureEnvelope.serialize(tempo_1.SignatureEnvelope.from(await sign({ hash: prepared.signPayload })));
            const { accessKey, chainId, expiry, limits, scopes, witness } = prepared;
            const { accessKeyAddress, keyType: type } = (0, Account_js_1.resolveAccessKey)(accessKey);
            const keyAuthorization = tempo_1.KeyAuthorization.from({
                account: account.address,
                address: accessKeyAddress,
                chainId: BigInt(chainId),
                signature: tempo_1.SignatureEnvelope.from({
                    account: account.address,
                    config,
                    signatures: [(0, Signature_js_1.parseApproval)(signature)],
                }),
                type,
                ...(witness ? { witness } : {}),
                expiry,
                limits,
                scopes,
            });
            return { keyAuthorization: tempo_1.KeyAuthorization.toRpc(keyAuthorization) };
        })();
        const operation = await client.request({
            method: 'account_approveKeyAuthorization',
            params: [request],
        });
        const operation_ = tempo_1.AccountOperation.fromRpc(operation);
        const keyAuthorization = tempo_1.KeyAuthorization.deserialize(await (async () => {
            if (operation_.status === 'success')
                return operation_.keyAuthorization;
            const approvals = await tempo_1.AccountOperation.selectApprovals({
                account: operation_.account,
                approvals: operation_.approvals,
                config: operation_.config,
                hash: operation_.hash,
            });
            return tempo_1.AccountOperation.serializeKeyAuthorization(operation_.keyAuthorization, {
                account: operation_.account,
                approvals: approvals.selectedApprovals.length > 0
                    ? approvals.selectedApprovals
                    : approvals.approvals.slice(0, 1),
                config: operation_.config,
            });
        })());
        if (!keyAuthorization.signature)
            throw new Error('Expected a signed configurable account key authorization.');
        return {
            ...keyAuthorization,
            hash: operation_.hash,
            operation: operation_,
            status: operation_.status,
        };
    }
    const keyAuthorization = await signLocal(client, parameters);
    if (client.transport.keyAuthorization)
        await saveAuthorization(client, { keyAuthorization }).catch((error) => {
            if (error instanceof rpc_js_1.MethodNotFoundRpcError ||
                error instanceof rpc_js_1.MethodNotSupportedRpcError)
                return;
            throw error;
        });
    return keyAuthorization;
}
async function signLocal(client, parameters) {
    const prepared = ('signPayload' in parameters
        ? parameters
        : await prepareAuthorization(client, parameters));
    const { accessKey, account: account_, chainId, configurable: configurableState, signPayload: _, ...rest } = prepared;
    return (0, Account_js_1.signKeyAuthorization)(account_, {
        chainId: BigInt(chainId),
        key: accessKey,
        configurable: configurableState,
        ...rest,
    });
}
async function updateLimit(client, parameters) {
    return updateLimit.inner(writeContract_js_1.writeContract, client, parameters);
}
(function (updateLimit) {
    async function inner(action, client, parameters) {
        const { accessKey, token, limit, ...rest } = parameters;
        const call = updateLimit.call({ accessKey, token, limit });
        return (await (0, errors_js_2.withExecutionError)(action)(client, {
            ...rest,
            ...call,
        }));
    }
    updateLimit.inner = inner;
    function call(args) {
        const { accessKey, token, limit } = args;
        return (0, utils_js_1.defineCall)({
            address: Addresses.accountKeychain,
            abi: Abis.accountKeychain,
            functionName: 'updateSpendingLimit',
            args: [resolveAccessKeyAddress(accessKey), token, limit],
        });
    }
    Object.defineProperty(updateLimit, "call", { configurable: true, enumerable: true, value: call, writable: true });
    function extractEvent(logs) {
        const [log] = (0, parseEventLogs_js_1.parseEventLogs)({
            abi: Abis.accountKeychain,
            logs,
            eventName: 'SpendingLimitUpdated',
            strict: true,
        });
        if (!log)
            throw new Error('`SpendingLimitUpdated` event not found.');
        return log;
    }
    updateLimit.extractEvent = extractEvent;
})(updateLimit || (exports.updateLimit = updateLimit = {}));
async function updateLimitSync(client, parameters) {
    const { throwOnReceiptRevert = true, ...rest } = parameters;
    const receipt = await updateLimit.inner(writeContractSync_js_1.writeContractSync, client, {
        ...rest,
        throwOnReceiptRevert,
    });
    if (receipt.status === 'pending')
        return { receipt };
    const { args } = updateLimit.extractEvent(receipt.logs);
    return {
        account: args.account,
        publicKey: args.publicKey,
        token: args.token,
        limit: args.newLimit,
        receipt,
    };
}
function watchWitness(client, parameters) {
    const { onWitness, ...rest } = parameters;
    return (0, watchContractEvent_js_1.watchContractEvent)(client, {
        ...rest,
        address: Addresses.accountKeychain,
        abi: Abis.accountKeychain,
        eventName: 'KeyAuthorizationWitness',
        onLogs: (logs) => {
            for (const log of logs)
                onWitness(log.args, log);
        },
        strict: true,
    });
}
function watchWitnessBurned(client, parameters) {
    const { onBurned, ...rest } = parameters;
    return (0, watchContractEvent_js_1.watchContractEvent)(client, {
        ...rest,
        address: Addresses.accountKeychain,
        abi: Abis.accountKeychain,
        eventName: 'KeyAuthorizationWitnessBurned',
        onLogs: (logs) => {
            for (const log of logs)
                onBurned(log.args, log);
        },
        strict: true,
    });
}
async function verifyHash(client, parameters) {
    const { account, admin, hash, signature, ...rest } = parameters;
    return (0, errors_js_2.withExecutionError)(readContract_js_1.readContract)(client, {
        ...rest,
        ...verifyHash.call({ account, admin, hash, signature }),
    });
}
(function (verifyHash) {
    function call(args) {
        const { account, admin = true, hash, signature } = args;
        return (0, utils_js_1.defineCall)({
            address: Addresses.signatureVerifier,
            abi: Abis.signatureVerifier,
            functionName: admin ? 'verifyKeychainAdmin' : 'verifyKeychain',
            args: [account, hash, signature],
        });
    }
    Object.defineProperty(verifyHash, "call", { configurable: true, enumerable: true, value: call, writable: true });
})(verifyHash || (exports.verifyHash = verifyHash = {}));
function resolveAccessKeyAddress(accessKey) {
    if (typeof accessKey === 'string')
        return accessKey;
    return accessKey.accessKeyAddress;
}
class AccessKeyError extends errors_js_1.TempoExecutionError {
    constructor(parameters, options = {}) {
        const { account, accessKey } = parameters;
        super(parameters, {
            shortMessage: `Access key "${accessKey}" failed: ${parameters.error.message}`,
            ...options,
            details: { account, 'access key': accessKey, ...options.details },
            docsPath: '/tempo/guides/access-keys/manage',
            name: options.name ?? 'AccessKeyError',
        });
        Object.defineProperty(this, "account", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "accessKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.account = account;
        this.accessKey = accessKey;
    }
}
exports.AccessKeyError = AccessKeyError;
class AccessKeySpendingLimitExceededError extends AccessKeyError {
    constructor(parameters) {
        const { amount, decimals, fee, periodEnd, remaining, token } = parameters;
        super(parameters, {
            details: {
                token,
                amount: (0, errors_js_2.formatAmount)(amount, decimals),
                remaining: (0, errors_js_2.formatAmount)(remaining, decimals),
                'exceeded by': amount !== undefined && remaining !== undefined
                    ? (0, errors_js_2.formatAmount)(amount - remaining, decimals)
                    : undefined,
                'resets at': (0, errors_js_2.formatTime)(periodEnd),
            },
            name: 'AccessKeySpendingLimitExceededError',
            shortMessage: `Access key "${parameters.accessKey}" exceeded its spending limit${token ? ` for token "${token}"` : ''}${fee ? ' while paying fees' : ''}.`,
        });
        Object.defineProperty(this, "amount", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "decimals", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "fee", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "periodEnd", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "remaining", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "token", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.amount = amount;
        this.decimals = decimals;
        this.fee = fee;
        this.periodEnd = periodEnd;
        this.remaining = remaining;
        this.token = token;
    }
}
exports.AccessKeySpendingLimitExceededError = AccessKeySpendingLimitExceededError;
class AccessKeyExpiredError extends AccessKeyError {
    constructor(parameters) {
        super(parameters, {
            details: { 'expired at': (0, errors_js_2.formatTime)(parameters.expiry) },
            name: 'AccessKeyExpiredError',
            shortMessage: `Access key "${parameters.accessKey}" has expired.`,
        });
        Object.defineProperty(this, "expiry", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.expiry = parameters.expiry;
    }
}
exports.AccessKeyExpiredError = AccessKeyExpiredError;
class AccessKeyCallNotAllowedError extends AccessKeyError {
    constructor(parameters) {
        const { selector, target } = parameters;
        super(parameters, {
            details: { target, selector },
            name: 'AccessKeyCallNotAllowedError',
            shortMessage: `Access key "${parameters.accessKey}" is not allowed to make this call.`,
        });
        Object.defineProperty(this, "selector", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "target", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.selector = selector;
        this.target = target;
    }
}
exports.AccessKeyCallNotAllowedError = AccessKeyCallNotAllowedError;
class AccessKeyAlreadyExistsError extends AccessKeyError {
    constructor(parameters) {
        const { expiry, limited } = parameters;
        super(parameters, {
            details: {
                expires: (0, errors_js_2.formatTime)(expiry),
                'spending limits': limited === undefined ? undefined : limited ? 'enforced' : 'none',
            },
            name: 'AccessKeyAlreadyExistsError',
            shortMessage: `Access key "${parameters.accessKey}" is already authorized on account "${parameters.account}".`,
        });
        Object.defineProperty(this, "expiry", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "limited", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.expiry = expiry;
        this.limited = limited;
    }
}
exports.AccessKeyAlreadyExistsError = AccessKeyAlreadyExistsError;
class AccessKeySignatureTypeMismatchError extends AccessKeyError {
    constructor(parameters) {
        const [expected, actual] = (parameters.error.args ?? []).map((type) => signatureTypes[Number(type)]);
        super(parameters, {
            details: { expected, actual },
            name: 'AccessKeySignatureTypeMismatchError',
            shortMessage: `Access key "${parameters.accessKey}" signed with a ${actual ?? 'different'} key, but was authorized as a ${expected ?? 'different'} key.`,
        });
        Object.defineProperty(this, "expected", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "actual", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.expected = expected;
        this.actual = actual;
    }
}
exports.AccessKeySignatureTypeMismatchError = AccessKeySignatureTypeMismatchError;
class AccessKeyExpiryInPastError extends AccessKeyError {
    constructor(parameters) {
        const { expiry, minimum } = parameters;
        super(parameters, {
            details: { expiry: (0, errors_js_2.formatTime)(expiry), minimum: (0, errors_js_2.formatTime)(minimum) },
            name: 'AccessKeyExpiryInPastError',
            shortMessage: `Access key "${parameters.accessKey}" expiry must be later${minimum ? ` than ${(0, errors_js_2.formatTime)(minimum)}` : ''}.`,
        });
        Object.defineProperty(this, "expiry", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "minimum", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.expiry = expiry;
        this.minimum = minimum;
    }
}
exports.AccessKeyExpiryInPastError = AccessKeyExpiryInPastError;
const keychain = {
    address: Addresses.accountKeychain,
    abi: Abis.accountKeychain,
};
function getSigner(context) {
    const { call, parameters, signer } = context;
    if (!signer?.accessKey)
        return undefined;
    if (call && (0, isAddressEqual_js_1.isAddressEqual)(call.address, Addresses.accountKeychain))
        return undefined;
    const authorized = parameters.keyAuthorization?.address;
    if (authorized && !(0, isAddressEqual_js_1.isAddressEqual)(authorized, signer.accessKey))
        return undefined;
    return {
        ...context.base,
        account: signer.address,
        accessKey: signer.accessKey,
    };
}
function getFeePayer(context) {
    const { feePayer } = context.parameters;
    if (typeof feePayer !== 'object')
        return undefined;
    const account = (0, parseAccount_js_1.parseAccount)(feePayer);
    if (account.source !== 'accessKey' || !('accessKeyAddress' in account))
        return undefined;
    return {
        ...context.base,
        account: account.address,
        accessKey: account.accessKeyAddress,
    };
}
function getAuthorization(context) {
    const { call, parameters, signer } = context;
    const accessKey = parameters.keyAuthorization?.address ??
        call?.arg('keyId');
    if (!signer || !accessKey)
        return undefined;
    return { ...context.base, account: signer.address, accessKey };
}
exports.errorResolvers = {
    ...Object.fromEntries(Abis.accountKeychain.flatMap((item) => item.type === 'error'
        ? [
            [
                (0, formatAbiItem_js_1.formatAbiItem)(item),
                (context) => {
                    const parameters = getSigner(context);
                    return parameters && new AccessKeyError(parameters);
                },
            ],
        ]
        : [])),
    'CallNotAllowed()': (context) => {
        const parameters = getSigner(context);
        if (!parameters)
            return undefined;
        return new AccessKeyCallNotAllowedError({
            ...parameters,
            selector: context.parameters.data?.slice(0, 10),
            target: context.call?.address ?? context.parameters.to,
        });
    },
    'ExpiryInPast()': (context) => {
        const parameters = getAuthorization(context);
        if (!parameters)
            return undefined;
        const [, expiry, minimum] = /expiry (\d+) <= min allowed (\d+)/.exec(context.details) ?? [];
        const requested = context.parameters.keyAuthorization?.expiry ??
            context.call?.arg('expiry') ??
            context.call?.arg('config')?.expiry;
        return new AccessKeyExpiryInPastError({
            ...parameters,
            expiry: expiry
                ? BigInt(expiry)
                : requested === undefined || requested === null
                    ? undefined
                    : BigInt(requested),
            minimum: minimum ? BigInt(minimum) : undefined,
        });
    },
    'KeyAlreadyExists()': async (context) => {
        const parameters = getAuthorization(context);
        if (!parameters)
            return undefined;
        const [key] = await context.read([
            {
                ...keychain,
                functionName: 'getKey',
                args: [parameters.account, parameters.accessKey],
            },
        ]);
        return new AccessKeyAlreadyExistsError({
            ...parameters,
            expiry: key?.result?.expiry,
            limited: key?.result?.enforceLimits,
        });
    },
    'KeyExpired()': async (context) => {
        const parameters = getSigner(context);
        if (!parameters)
            return undefined;
        const [key] = await context.read([
            {
                ...keychain,
                functionName: 'getKey',
                args: [parameters.account, parameters.accessKey],
            },
        ]);
        return new AccessKeyExpiredError({
            ...parameters,
            expiry: key?.result?.expiry,
        });
    },
    'SignatureTypeMismatch(uint8,uint8)': (context) => {
        const parameters = getSigner(context) ?? getAuthorization(context);
        return parameters && new AccessKeySignatureTypeMismatchError(parameters);
    },
    'SpendingLimitExceeded()': async (context) => {
        const fee = context.validation;
        const parameters = fee && context.parameters.feePayer
            ? getFeePayer(context)
            : getSigner(context);
        if (!parameters)
            return undefined;
        const token = fee
            ? (0, errors_js_2.getFeeToken)(context)
            : (0, utils_js_1.isTip20)(context.call?.address)
                ? context.call.address
                : undefined;
        if (!token)
            return new AccessKeySpendingLimitExceededError({
                ...parameters,
                fee,
                hints: fee
                    ? [...parameters.hints, 'Pay fees with another token.']
                    : parameters.hints,
            });
        const args = [parameters.account, parameters.accessKey, token];
        const [withPeriod, legacy, decimals] = await context.read([
            { ...keychain, functionName: 'getRemainingLimitWithPeriod', args },
            { ...keychain, functionName: 'getRemainingLimit', args },
            { address: token, abi: Abis.tip20, functionName: 'decimals' },
        ]);
        return new AccessKeySpendingLimitExceededError({
            ...parameters,
            amount: fee ? undefined : context.call?.arg('amount'),
            decimals: decimals?.result,
            fee,
            periodEnd: withPeriod?.result?.[1] || undefined,
            remaining: withPeriod?.result?.[0] ?? legacy?.result,
            token,
        });
    },
};
//# sourceMappingURL=accessKey.js.map