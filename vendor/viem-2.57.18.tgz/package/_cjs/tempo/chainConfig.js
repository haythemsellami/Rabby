"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.chainConfig = void 0;
const Hex = require("ox/Hex");
const tempo_1 = require("ox/tempo");
const getCode_js_1 = require("../actions/public/getCode.js");
const getTransaction_js_1 = require("../actions/public/getTransaction.js");
const readContract_js_1 = require("../actions/public/readContract.js");
const verifyHash_js_1 = require("../actions/public/verifyHash.js");
const number_js_1 = require("../constants/number.js");
const base_js_1 = require("../errors/base.js");
const contract_js_1 = require("../errors/contract.js");
const isAddressEqual_js_1 = require("../utils/address/isAddressEqual.js");
const defineChain_js_1 = require("../utils/chain/defineChain.js");
const transaction_js_1 = require("../utils/formatters/transaction.js");
const transactionReceipt_js_1 = require("../utils/formatters/transactionReceipt.js");
const transactionRequest_js_1 = require("../utils/formatters/transactionRequest.js");
const getAction_js_1 = require("../utils/getAction.js");
const keccak256_js_1 = require("../utils/hash/keccak256.js");
const accessKey_js_1 = require("./actions/accessKey.js");
const accounts_js_1 = require("./actions/accounts.js");
const Formatters = require("./Formatters.js");
const Concurrent = require("./internal/concurrent.js");
const PreAuthorized = require("./internal/preAuthorized.js");
const replacement_js_1 = require("./internal/replacement.js");
const Transaction = require("./Transaction.js");
const expiringNonceExpiry = 270;
const serializeTransaction = ((transaction, signature) => Transaction.serialize(transaction, signature));
exports.chainConfig = {
    blockTime: 1_000,
    extendSchema: (0, defineChain_js_1.extendSchema)(),
    formatters: {
        block: {
            format: (block) => Formatters.formatBlock(block),
            type: 'block',
        },
        transaction: {
            ...(0, transaction_js_1.defineTransaction)({
                exclude: ['aaAuthorizationList'],
                format: Formatters.formatTransaction,
            }),
            format: (transaction) => Formatters.formatTransaction(transaction),
        },
        transactionReceipt: (0, transactionReceipt_js_1.defineTransactionReceipt)({
            format: Formatters.formatTransactionReceipt,
        }),
        transactionRequest: (0, transactionRequest_js_1.defineTransactionRequest)({
            format: Formatters.formatTransactionRequest,
        }),
    },
    prepareTransactionRequest: [
        async (r, { client, error, phase }) => {
            const request = r;
            if (phase === 'afterFillTransactionError') {
                const refused = error instanceof base_js_1.BaseError &&
                    error.walk((cause) => cause.details?.includes('KeyAlreadyExists'));
                const pending = refused ? await getPending(request) : undefined;
                if (!pending)
                    return undefined;
                await pending.manager.remove(pending.key);
                const { keyAuthorization: _, ...retry } = request;
                return retry;
            }
            if (phase === 'beforeFillParameters') {
                if (typeof request.gas !== 'undefined' ||
                    !request.parameters?.includes('gas'))
                    return request;
                const pending = await getPending(request);
                if (pending && (await isRegistered(client, pending.key))) {
                    await pending.manager.remove(pending.key);
                    delete request.keyAuthorization;
                }
                return request;
            }
            if (request.hash) {
                const local = (() => {
                    const account = request.account;
                    if (!account || typeof account === 'string')
                        return undefined;
                    if (account.source === 'configurable')
                        return account;
                    if (account.source === 'accessKey')
                        return account
                            .delegate;
                    return undefined;
                })();
                if (!request.account || typeof request.account === 'string' || !local)
                    throw new Error('A local configurable account is required to approve a stored configurable account transaction.');
                if (!request.owner || typeof request.owner === 'string')
                    throw new Error('A local owner account is required to approve a stored configurable account transaction.');
                if (request.owner.source !== 'root')
                    throw new Error('A Tempo owner account is required to approve a stored configurable account transaction.');
                const transaction = await (0, getAction_js_1.getAction)(client, getTransaction_js_1.getTransaction, 'getTransaction')({ hash: request.hash });
                const operation = 'operation' in transaction
                    ? transaction.operation
                    : undefined;
                if (!operation)
                    throw new Error('Expected an account operation transaction.');
                const parent = local === request.account ? undefined : request.account;
                if (!(0, isAddressEqual_js_1.isAddressEqual)(operation.account, local.address) ||
                    (parent
                        ? !operation.userAddress ||
                            !(0, isAddressEqual_js_1.isAddressEqual)(operation.userAddress, parent.address)
                        : !!operation.userAddress))
                    throw new Error('Account operation account does not match the requested account.');
                const storedTransaction = Transaction.deserialize(operation.transaction);
                const hash = tempo_1.AccountOperation.getHash({
                    account: operation.account,
                    config: operation.config,
                    transaction: operation.transaction,
                    type: 'transaction',
                    userAddress: operation.userAddress,
                });
                if (hash.toLowerCase() !== request.hash.toLowerCase())
                    throw new Error('Account operation hash does not match transaction.');
                return {
                    ...storedTransaction,
                    gas: storedTransaction.gas ?? 0n,
                    maxFeePerGas: storedTransaction.maxFeePerGas ?? 0n,
                    maxPriorityFeePerGas: storedTransaction.maxPriorityFeePerGas ?? 0n,
                    account: request.account,
                    from: operation.userAddress ?? operation.account,
                    accountSimulation: {
                        ...getAccountSimulation({ config: operation.config, local }),
                        ...(parent ? { signer: local.address } : {}),
                    },
                    owner: request.owner,
                };
            }
            if (phase === 'afterFillParameters') {
                const approved = Array.isArray(request.signatures) &&
                    request.signatures.length > 0;
                if (typeof request.gas !== 'undefined' &&
                    request.feePayer &&
                    !request.feePayerSignature &&
                    !approved) {
                    request.gas = (request.gas ?? 0n) + feePayerGas;
                    if (request.keyAuthorization?.signature.type === 'webAuthn')
                        request.gas = (request.gas ?? 0n) + 20000n;
                    else if (request.account?.source === 'accessKey')
                        request.gas = (request.gas ?? 0n) + 10000n;
                }
                return request;
            }
            const configurableIdentity = (() => {
                if (request.account?.source === 'configurable')
                    return {
                        account: request.account.address,
                        config: request.account.config,
                        local: request.account,
                    };
                return undefined;
            })();
            const delegate = request.account?.source === 'accessKey'
                ? request.account.delegate
                : undefined;
            if (request.owner && !configurableIdentity && !delegate)
                throw new Error('A configurable account is required when an owner is provided.');
            if (request.owner && typeof request.owner === 'string')
                throw new Error('A local owner account is required to approve a configurable account transaction.');
            if (request.owner && request.owner.source !== 'root')
                throw new Error('A Tempo owner account is required to approve a configurable account transaction.');
            const coordinated = (!!configurableIdentity || !!delegate) &&
                !!request.owner &&
                client.transport.accounts === true;
            if (configurableIdentity) {
                const { account, local } = configurableIdentity;
                if (!configurableIdentity.config && !coordinated)
                    throw new Error('An account config is required to prepare a transaction.');
                const config = configurableIdentity.config ??
                    (await (0, getAction_js_1.getAction)(client, accounts_js_1.getConfig, 'getConfig')({ address: account }));
                if (!config)
                    throw new Error(`No current account config is cached for account ${account}. Provide the current config.`);
                request.from = account;
                request.accountSimulation = getAccountSimulation({
                    config,
                    local,
                });
            }
            if (delegate) {
                const config = delegate.config ??
                    (client.transport.accounts === true
                        ? await (0, getAction_js_1.getAction)(client, accounts_js_1.getConfig, 'getConfig')({ address: delegate.address })
                        : undefined);
                if (!config)
                    throw new Error('An account config is required to prepare a transaction.');
                request.accountSimulation = {
                    ...getAccountSimulation({ config, local: delegate }),
                    signer: delegate.address,
                };
            }
            if (coordinated && typeof request.nonceKey === 'undefined') {
                request.nonceKey = Hex.toBigInt(Hex.random(31)) + 1n;
                request.nonce = 0;
            }
            else if (await useExpiringNonce(request, !!configurableIdentity)) {
                request.nonceKey = number_js_1.maxUint256;
                request.nonce ??= Hex.toNumber(Hex.random(6));
                if (typeof request.validBefore === 'undefined')
                    request.validBefore =
                        Math.floor(Date.now() / 1000) + expiringNonceExpiry;
            }
            else if (typeof request.nonceKey !== 'undefined' &&
                BigInt(request.nonceKey) !== 0n) {
                request.nonce = typeof request.nonce === 'number' ? request.nonce : 0;
            }
            if (!request.keyAuthorization &&
                request.account?.source === 'accessKey') {
                const keyAuthorizationManager = request.account.keyAuthorizationManager;
                if (keyAuthorizationManager) {
                    const chainId = request.chainId ?? request.chain?.id;
                    if (typeof chainId !== 'undefined') {
                        const address = request.account.address;
                        const accessKey = request.account.accessKeyAddress;
                        const key = { address, accessKey, chainId };
                        const keyAuthorization = await keyAuthorizationManager.get(key);
                        if (keyAuthorization) {
                            const now = BigInt(Math.floor(Date.now() / 1000));
                            if (keyAuthorization.expiry != null &&
                                BigInt(keyAuthorization.expiry) <= now) {
                                await keyAuthorizationManager.remove(key);
                            }
                            else if ((request.parameters?.includes('gas') &&
                                typeof request.gas === 'undefined') ||
                                !(await isRegistered(client, key)))
                                request.keyAuthorization = keyAuthorization;
                            else
                                await keyAuthorizationManager.remove(key);
                        }
                    }
                }
            }
            const keyAuthorizationSimulation = getKeyAuthorizationSimulation(request.keyAuthorization);
            if (keyAuthorizationSimulation)
                request.keyAuthorizationSimulation = keyAuthorizationSimulation;
            if (!request.feeToken && request.chain?.feeToken)
                request.feeToken = request.chain.feeToken;
            return request;
        },
        {
            runAt: [
                'beforeFillTransaction',
                'afterFillTransactionError',
                'beforeFillParameters',
                'afterFillParameters',
            ],
        },
    ],
    serializers: {
        transaction: serializeTransaction,
        async transactionEnvelope({ serializedTransaction, transaction }) {
            const request = transaction;
            if (!request.accountSimulation)
                return serializedTransaction;
            try {
                tempo_1.SignatureEnvelope.deserialize(serializedTransaction);
            }
            catch {
                const transaction = Transaction.deserialize(serializedTransaction);
                if (transaction.signature?.type === 'configurable' ||
                    transaction.signature?.type === 'keychain')
                    return serializedTransaction;
                throw new Error('A Tempo owner account is required to approve a configurable account transaction.');
            }
            return await serializeTransaction({
                ...request,
                signatures: [...(request.signatures ?? []), serializedTransaction],
            });
        },
    },
    transactionReplacement: replacement_js_1.transactionReplacement,
    async verifyHash(client, parameters) {
        const { address, hash, signature, mode } = parameters;
        const serialized = (() => {
            if (typeof signature === 'string')
                return signature;
            if (signature instanceof Uint8Array)
                return Hex.fromBytes(signature);
            return undefined;
        })();
        if (serialized &&
            mode === 'allowAccessKey' &&
            PreAuthorized.isPreAuthorized(serialized))
            return await PreAuthorized.verify(client, {
                account: address,
                blockHash: parameters.blockHash,
                blockNumber: parameters.blockNumber,
                blockTag: parameters.blockTag,
                chainId: (parameters.chain ?? client.chain)?.id,
                hash,
                requireCanonical: parameters.requireCanonical,
                signature: serialized,
            });
        const envelope = (() => {
            if (!serialized)
                return;
            try {
                return tempo_1.SignatureEnvelope.deserialize(serialized);
            }
            catch {
                return undefined;
            }
        })();
        if (envelope) {
            if (envelope?.type === 'keychain' && mode === 'allowAccessKey') {
                const { inner, userAddress, version } = envelope;
                if (!(0, isAddressEqual_js_1.isAddressEqual)(userAddress, address))
                    return false;
                const block = {
                    blockHash: parameters.blockHash,
                    blockNumber: parameters.blockNumber,
                    blockTag: parameters.blockTag,
                    requireCanonical: parameters.requireCanonical,
                };
                if (inner.type === 'configurable') {
                    if (version !== 'v2')
                        return false;
                    const [keyInfo, valid] = await Promise.all([
                        (0, accessKey_js_1.getMetadata)(client, {
                            ...block,
                            account: address,
                            accessKey: inner.account,
                        }),
                        (0, readContract_js_1.readContract)(client, {
                            ...block,
                            ...accounts_js_1.verifyHash.call({
                                account: inner.account,
                                hash: (0, keccak256_js_1.keccak256)(Hex.concat('0x04', hash, address)),
                                signature: tempo_1.SignatureEnvelope.serialize(inner),
                            }),
                        }).catch(catchRevert),
                    ]);
                    if (keyInfo.isRevoked)
                        return false;
                    if (keyInfo.expiry <= BigInt(Math.floor(Date.now() / 1000)))
                        return false;
                    if (!valid || keyInfo.keyType === 'configurable')
                        return valid;
                    const commitment = (await (0, readContract_js_1.readContract)(client, {
                        ...block,
                        ...accounts_js_1.getConfigCommitment.call({ account: inner.account }),
                    }));
                    return BigInt(commitment) !== 0n;
                }
                if (version === 'v2')
                    return await (0, readContract_js_1.readContract)(client, {
                        ...block,
                        ...accessKey_js_1.verifyHash.call({
                            account: address,
                            admin: false,
                            hash,
                            signature: serialized,
                        }),
                    }).catch(catchRevert);
                const accessKeyAddress = (() => {
                    try {
                        return tempo_1.SignatureEnvelope.extractAddress({
                            payload: hash,
                            signature: inner,
                        });
                    }
                    catch {
                        return undefined;
                    }
                })();
                if (!accessKeyAddress)
                    return false;
                const keyInfo = await (0, accessKey_js_1.getMetadata)(client, {
                    ...block,
                    account: address,
                    accessKey: accessKeyAddress,
                });
                if (keyInfo.isRevoked)
                    return false;
                if (keyInfo.expiry <= BigInt(Math.floor(Date.now() / 1000)))
                    return false;
                return tempo_1.SignatureEnvelope.verify(inner, {
                    address: accessKeyAddress,
                    payload: hash,
                });
            }
            if (envelope.type === 'configurable')
                return await (0, readContract_js_1.readContract)(client, {
                    blockHash: parameters.blockHash,
                    blockNumber: parameters.blockNumber,
                    blockTag: parameters.blockTag,
                    requireCanonical: parameters.requireCanonical,
                    ...accounts_js_1.verifyHash.call({
                        account: address,
                        hash,
                        signature: serialized,
                    }),
                }).catch(catchRevert);
            if (envelope.type === 'p256' || envelope.type === 'webAuthn') {
                const code = await (0, getCode_js_1.getCode)(client, {
                    address,
                    blockHash: parameters.blockHash,
                    blockNumber: parameters.blockNumber,
                    blockTag: parameters.blockTag,
                    requireCanonical: parameters.requireCanonical,
                });
                if (!code ||
                    code === '0xef01007702c00000000000000000000000000000000000')
                    return tempo_1.SignatureEnvelope.verify(envelope, {
                        address,
                        payload: hash,
                    });
            }
        }
        return await (0, getAction_js_1.getAction)(client, verifyHash_js_1.verifyHash, 'verifyHash')({ ...parameters, chain: null });
    },
};
async function getPending(request) {
    const { account, keyAuthorization } = request;
    if (!keyAuthorization || account?.source !== 'accessKey')
        return undefined;
    const manager = account.keyAuthorizationManager;
    const chainId = request.chainId ?? request.chain?.id;
    if (!manager || typeof chainId === 'undefined')
        return undefined;
    const key = {
        address: account.address,
        accessKey: account.accessKeyAddress,
        chainId,
    };
    const pending = await manager.get(key);
    if (!pending ||
        tempo_1.KeyAuthorization.serialize(pending) !==
            tempo_1.KeyAuthorization.serialize(keyAuthorization))
        return undefined;
    return { key, manager };
}
async function isRegistered(client, key) {
    const metadata = await (0, getAction_js_1.getAction)(client, accessKey_js_1.getMetadata, 'getMetadata')({ account: key.address, accessKey: key.accessKey });
    return ((0, isAddressEqual_js_1.isAddressEqual)(metadata.address, key.accessKey) &&
        !metadata.isRevoked &&
        metadata.expiry > BigInt(Math.floor(Date.now() / 1000)));
}
async function useExpiringNonce(request, configurable) {
    const { account, feePayer, nonceKey } = request;
    if (nonceKey === 'expiring' || nonceKey === number_js_1.maxUint256)
        return true;
    if (typeof nonceKey !== 'undefined' || configurable)
        return false;
    if (feePayer)
        return true;
    const address = typeof account === 'string' ? account : account?.address;
    if (!address)
        return false;
    return await Concurrent.detect(address.toLowerCase());
}
function getAccountSimulation(options) {
    const { config, local } = options;
    return {
        approvals: selectOwners(config).map((owner) => {
            const localOwner = local?.owners.find((account) => (0, isAddressEqual_js_1.isAddressEqual)(account.address, owner.owner));
            return {
                ...getSimulationKey(localOwner),
                owner: owner.owner,
            };
        }),
        config,
    };
}
function getKeyAuthorizationSimulation(keyAuthorization) {
    if (keyAuthorization?.signature.type !== 'configurable')
        return undefined;
    const { account, signatures } = keyAuthorization.signature;
    const config = tempo_1.AccountConfig.from(keyAuthorization.signature.config);
    const payload = tempo_1.AccountConfig.getSignPayload({
        account,
        config,
        payload: tempo_1.KeyAuthorization.getSignPayload(keyAuthorization),
    });
    const signed = new Set();
    let weight = 0;
    for (const signature of signatures) {
        const owner = (() => {
            try {
                return tempo_1.SignatureEnvelope.extractAddress({ payload, signature });
            }
            catch {
                return undefined;
            }
        })();
        const entry = owner
            ? config.owners.find((entry) => (0, isAddressEqual_js_1.isAddressEqual)(entry.owner, owner))
            : undefined;
        if (!entry || signed.has(entry.owner.toLowerCase()))
            continue;
        signed.add(entry.owner.toLowerCase());
        weight += Number(entry.weight);
    }
    if (weight >= Number(config.threshold))
        return undefined;
    return { ...getAccountSimulation({ config }), signer: account };
}
function catchRevert(error) {
    if (error instanceof base_js_1.BaseError &&
        error.walk((cause) => cause instanceof contract_js_1.ContractFunctionRevertedError))
        return false;
    throw error;
}
function getSimulationKey(account) {
    const keyType = (() => {
        if (account &&
            typeof account === 'object' &&
            'keyType' in account &&
            typeof account.keyType === 'string')
            return account.keyType;
        return undefined;
    })();
    if (!keyType || keyType === 'webAuthn')
        return { keyData: '0x0578', keyType: 'webAuthn' };
    if (keyType === 'p256' || keyType === 'secp256k1')
        return { keyType };
    return { keyData: '0x0578', keyType: 'webAuthn' };
}
function selectOwners(config) {
    const owners = [...config.owners].sort((a, b) => Number(b.weight) - Number(a.weight) ||
        a.owner.toLowerCase().localeCompare(b.owner.toLowerCase()));
    const selected = [];
    let weight = 0;
    for (const owner of owners.slice(0, tempo_1.AccountConfig.maxSignatures)) {
        if (weight >= Number(config.threshold))
            break;
        selected.push(owner);
        weight += Number(owner.weight);
    }
    return selected.sort((a, b) => a.owner.toLowerCase().localeCompare(b.owner.toLowerCase()));
}
const feePayerGas = 5000n;
//# sourceMappingURL=chainConfig.js.map