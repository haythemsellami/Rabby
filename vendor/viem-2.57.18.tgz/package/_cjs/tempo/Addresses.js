"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.zoneVerifier = exports.zonePortalImplementation = exports.zoneOutbox = exports.zoneInbox = exports.zoneMessenger = exports.zoneFactory = exports.validatorV2 = exports.validator = exports.tip403Registry = exports.tip20Factory = exports.tip20ChannelReserve = exports.storageCredits = exports.stablecoinDex = exports.signatureVerifier = exports.receivePolicyGuard = exports.pathUsd = exports.ousd = exports.nonceManager = exports.feeManager = exports.currentCommittee = exports.configurableAccount = exports.addressRegistry = exports.accountRegistrar = exports.accountKeychain = exports.accountImplementation = void 0;
exports.zonePortal = zonePortal;
const Hex = require("ox/Hex");
const tempo_1 = require("ox/tempo");
const legacyZoneChainIdBase = 4_217_000_000;
const legacyZoneChainIdLimit = 4_218_000_000;
const mainnetZoneChainIdBase = tempo_1.ZoneId.toChainId(0);
const testnetZoneChainIdBase = tempo_1.ZoneId.toChainId(0, 42_431);
const zoneChainIdLimit = 2 ** 31;
exports.accountImplementation = '0x7702c00000000000000000000000000000000000';
exports.accountKeychain = '0xaAAAaaAA00000000000000000000000000000000';
exports.accountRegistrar = '0x7702ac0000000000000000000000000000000000';
exports.addressRegistry = '0xfdc0000000000000000000000000000000000000';
exports.configurableAccount = '0xAACC000000000000000000000000000000000000';
exports.currentCommittee = '0xC077e00000000000000000000000000000000000';
exports.feeManager = '0xfeec000000000000000000000000000000000000';
exports.nonceManager = '0x4e4F4E4345000000000000000000000000000000';
exports.ousd = '0x20c0000000000000000000006a37DA5C996874BE';
exports.pathUsd = '0x20c0000000000000000000000000000000000000';
exports.receivePolicyGuard = '0xB10C000000000000000000000000000000000000';
exports.signatureVerifier = '0x5165300000000000000000000000000000000000';
exports.stablecoinDex = '0xdec0000000000000000000000000000000000000';
exports.storageCredits = '0x1060000000000000000000000000000000000000';
exports.tip20ChannelReserve = '0x4d50500000000000000000000000000000000000';
exports.tip20Factory = '0x20fc000000000000000000000000000000000000';
exports.tip403Registry = '0x403c000000000000000000000000000000000000';
exports.validator = '0xcccccccc00000000000000000000000000000000';
exports.validatorV2 = '0xcccccccc00000000000000000000000000000001';
exports.zoneFactory = '0x5aF2000000000000000000000000000000000000';
exports.zoneMessenger = '0x5A4d000000000000000000000000000000000000';
exports.zoneInbox = '0x1c00000000000000000000000000000000000001';
exports.zoneOutbox = '0x1c00000000000000000000000000000000000002';
exports.zonePortalImplementation = '0x5AD1000000000000000000000000000000000000';
exports.zoneVerifier = '0x5a56000000000000000000000000000000000000';
function zonePortal(id) {
    const zoneId = normalizeZoneId(id);
    if (zoneId === 6)
        return '0x7069DeC4E64Fd07334A0933eDe836C17259c9B23';
    if (zoneId === 7)
        return '0x3F5296303400B56271b476F5A0B9cBF74350D6Ac';
    const suffix = Hex.fromNumber(zoneId, { size: 8 }).slice(2);
    return `0x5ad000000000000000000000${suffix}`;
}
function normalizeZoneId(id) {
    if (id >= legacyZoneChainIdBase && id < legacyZoneChainIdLimit)
        return id - legacyZoneChainIdBase;
    if (id >= testnetZoneChainIdBase && id < zoneChainIdLimit)
        return tempo_1.ZoneId.fromChainId(id, 42_431);
    if (id >= mainnetZoneChainIdBase && id < testnetZoneChainIdBase)
        return tempo_1.ZoneId.fromChainId(id);
    return id;
}
//# sourceMappingURL=Addresses.js.map