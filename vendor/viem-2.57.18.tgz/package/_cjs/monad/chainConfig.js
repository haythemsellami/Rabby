"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.chainConfig = void 0;
const parseAccount_js_1 = require("../accounts/utils/parseAccount.js");
const block_js_1 = require("../utils/formatters/block.js");
const transaction_js_1 = require("../utils/formatters/transaction.js");
const transactionReceipt_js_1 = require("../utils/formatters/transactionReceipt.js");
const Formatters = require("./Formatters.js");
const internal = require("./internal/transaction.js");
const Submission = require("./Submission.js");
const Transaction = require("./Transaction.js");
exports.chainConfig = {
    formatters: {
        block: {
            ...(0, block_js_1.defineBlock)({ format: Formatters.formatBlock }),
            format: Formatters.formatBlock,
        },
        transaction: {
            ...(0, transaction_js_1.defineTransaction)({ format: Formatters.formatTransaction }),
            format: Formatters.formatTransaction,
        },
        transactionReceipt: (0, transactionReceipt_js_1.defineTransactionReceipt)({
            format: Formatters.formatTransactionReceipt,
        }),
        transactionRequest: {
            type: 'transactionRequest',
            format: Formatters.formatTransactionRequest,
        },
    },
    prepareTransactionRequest: [
        async (request, { client, phase }) => {
            if (request.type !== 'monad')
                return;
            const r = request;
            internal.assertRequest(r);
            if (phase !== 'beforeFillTransaction')
                return;
            if (request.chainId !== undefined &&
                request.chain &&
                request.chainId !== request.chain.id)
                throw new Transaction.InvalidEnvelopeError('chainId does not match the configured chain.');
            if (r.parameters?.includes('nonce') &&
                r.nonce === undefined &&
                r.account) {
                if (r.nonceManager)
                    throw new Transaction.InvalidEnvelopeError('Supply an explicit bigint nonce instead of a number-based nonce manager.');
                const account = (0, parseAccount_js_1.parseAccount)(r.account);
                r.nonce = internal.quantity(await client.request({
                    method: 'eth_getTransactionCount',
                    params: [account.address, 'pending'],
                }), 64, 'nonce');
            }
            return {
                ...request,
                ...r,
                chainId: request.chainId ?? request.chain?.id,
            };
        },
        { runAt: ['beforeFillTransaction', 'afterFillParameters'] },
    ],
    serializers: {
        transaction: internal.serializeTransaction,
        transactionEnvelope: ({ serializedTransaction, transaction }) => transaction.type === 'monad'
            ? Submission.serialize(Transaction.deserialize(serializedTransaction))
            : serializedTransaction,
    },
};
//# sourceMappingURL=chainConfig.js.map