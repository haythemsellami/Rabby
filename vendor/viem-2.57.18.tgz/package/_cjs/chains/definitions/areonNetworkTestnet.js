"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.areonNetworkTestnet = void 0;
const defineChain_js_1 = require("../../utils/chain/defineChain.js");
exports.areonNetworkTestnet = (0, defineChain_js_1.defineChain)({
    id: 462,
    name: 'Areon Network Testnet',
    nativeCurrency: { decimals: 18, name: 'TAREA', symbol: 'TAREA' },
    rpcUrls: {
        default: {
            http: ['https://testnet-rpc.areon.network'],
            webSocket: ['wss://testnet-ws.areon.network'],
        },
    },
    blockExplorers: {
        default: {
            name: 'Areonscan',
            url: 'https://areonscan.com',
        },
    },
    testnet: true,
});
//# sourceMappingURL=areonNetworkTestnet.js.map