"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.abstractTestnet = void 0;
const defineChain_js_1 = require("../../utils/chain/defineChain.js");
const chainConfig_js_1 = require("../../zksync/chainConfig.js");
exports.abstractTestnet = (0, defineChain_js_1.defineChain)({
    ...chainConfig_js_1.chainConfig,
    blockTime: 200,
    id: 11_124,
    name: 'Abstract Testnet',
    nativeCurrency: {
        decimals: 18,
        name: 'ETH',
        symbol: 'ETH',
    },
    rpcUrls: {
        default: { http: ['https://api.testnet.abs.xyz'] },
    },
    blockExplorers: {
        default: {
            name: 'Etherscan',
            url: 'https://sepolia.abscan.org',
        },
        native: {
            name: 'Abstract Explorer',
            url: 'https://explorer.testnet.abs.xyz',
        },
    },
    testnet: true,
    contracts: {
        multicall3: {
            address: '0xF9cda624FBC7e059355ce98a31693d299FACd963',
            blockCreated: 358349,
        },
        erc6492Verifier: {
            address: '0xfB688330379976DA81eB64Fe4BF50d7401763B9C',
            blockCreated: 431682,
        },
    },
});
//# sourceMappingURL=abstractTestnet.js.map