"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.blastSepolia = void 0;
const defineChain_js_1 = require("../../utils/chain/defineChain.js");
const sourceId = 11_155_111;
exports.blastSepolia = (0, defineChain_js_1.defineChain)({
    id: 168_587_773,
    name: 'Blast Sepolia',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18,
    },
    rpcUrls: {
        default: {
            http: ['https://sepolia.blast.io'],
        },
    },
    blockExplorers: {
        default: {
            name: 'Blastscan',
            url: 'https://sepolia.blastscan.io',
            apiUrl: 'https://api-sepolia.blastscan.io/api',
        },
    },
    contracts: {
        multicall3: {
            address: '0xca11bde05977b3631167028862be2a173976ca11',
            blockCreated: 756690,
        },
    },
    testnet: true,
    sourceId,
});
//# sourceMappingURL=blastSepolia.js.map