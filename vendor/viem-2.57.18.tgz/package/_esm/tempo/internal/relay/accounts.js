import * as Address_ from 'ox/Address';
import * as Hash from 'ox/Hash';
import * as Hex from 'ox/Hex';
import * as RpcResponse from 'ox/RpcResponse';
import { AccountConfig, AccountOperation, KeyAuthorization, Transaction as ox_Transaction, SignatureEnvelope, TxEnvelopeTempo, } from 'ox/tempo';
import { getBlockNumber } from '../../../actions/public/getBlockNumber.js';
import { createClient } from '../../../clients/createClient.js';
import { custom } from '../../../clients/transports/custom.js';
import { decodeFunctionData } from '../../../utils/abi/decodeFunctionData.js';
import { isAddressEqual } from '../../../utils/address/isAddressEqual.js';
import * as Abis from '../../Abis.js';
import * as Addresses from '../../Addresses.js';
import * as ConfigStore from '../../accounts/Config.js';
import * as OperationStore from '../../accounts/Operation.js';
import { getConfigCommitment } from '../../actions/accounts.js';
import * as Transaction from '../../Transaction.js';
import * as Plugin from './plugin.js';
import * as Utils from './utils.js';
const submissionTtl = 30_000;
const pollingInterval = 100;
/** Creates middleware for owner approval coordination. @internal */
export function create(options) {
    if (!options.store.compareAndSet)
        throw new RpcResponse.InvalidParamsError({
            message: 'Account coordination requires a store with atomic `compareAndSet`.',
        });
    return Plugin.accounts({
        async handleRequest(context, forward) {
            const { request, options: requestOptions_ } = context;
            const requestOptions = await resolveRequestOptions({
                request,
                requestOptions: requestOptions_,
                store: options.store,
            });
            context.options = requestOptions ?? {};
            const next = async (request, options) => {
                return context
                    .getClient(options?.chainId)
                    .request(request, options);
            };
            const client = createClient({
                transport: custom({
                    request: (request, options) => next(request, { ...requestOptions, ...options }),
                }, { retryCount: 0 }),
            });
            if (request.method === 'account_getConfig') {
                const value = request.params?.[0];
                const address = value && typeof value === 'object' && 'address' in value
                    ? value.address
                    : undefined;
                if (typeof address !== 'string' ||
                    !Address_.validate(address) ||
                    Hex.toBigInt(address) === 0n)
                    throw new RpcResponse.InvalidParamsError({
                        message: 'Expected a configurable account address.',
                    });
                const chainId = requestOptions?.chainId;
                if (chainId === undefined)
                    throw new RpcResponse.InvalidParamsError({
                        message: 'A chain ID is required to resolve the downstream client.',
                    });
                // Surface a downstream failure as its RPC error, not as a reverted read.
                const commitment = await getConfigCommitment(client, {
                    account: address,
                }).catch((error) => {
                    throw Utils.toRpcError(error);
                });
                const config = await ConfigStore.read(options.store, {
                    address,
                    chainId,
                    commitment,
                });
                if (config)
                    return AccountConfig.toRpc(config);
                const resolved = await options.resolveConfig?.({
                    address,
                    chainId,
                    commitment,
                });
                if (!resolved)
                    return null;
                try {
                    await ConfigStore.write(options.store, {
                        address,
                        chainId,
                        commitment,
                        config: resolved,
                    });
                }
                catch (error) {
                    // A resolved config that does not match the account and commitment is not served.
                    if (error instanceof ConfigStore.InvalidStoreValueError)
                        return null;
                    throw error;
                }
                return AccountConfig.toRpc(AccountConfig.from(resolved));
            }
            if (request.method === 'account_getOperation') {
                const hash = request.params?.[0];
                if (typeof hash !== 'string' || !Hash.validate(hash))
                    throw new RpcResponse.InvalidParamsError({
                        message: 'Expected an account operation hash.',
                    });
                const operation = await OperationStore.read(options.store, hash);
                return operation ? AccountOperation.toRpc(operation) : null;
            }
            if (request.method === 'account_approveKeyAuthorization')
                return await approveKeyAuthorization({
                    chainId: requestOptions?.chainId,
                    client,
                    request,
                    store: options.store,
                });
            if (request.method === 'eth_getTransactionByHash' ||
                request.method === 'eth_getTransactionReceipt') {
                const hash = request.params?.[0];
                if (typeof hash !== 'string' || !Hash.validate(hash))
                    return forward();
                const operation = await OperationStore.read(options.store, hash);
                if (!operation || operation.type !== 'transaction')
                    return forward();
                if (request.method === 'eth_getTransactionReceipt') {
                    if (operation.status === 'pending')
                        return null;
                    const transactionHash = await getSubmittedTransactionHash(options.store, operation);
                    if (!transactionHash)
                        return null;
                    const receipt = await next({
                        ...request,
                        params: [transactionHash],
                    }, requestOptions);
                    if (!receipt || typeof receipt !== 'object')
                        return receipt;
                    const success = operation.status === 'submitting'
                        ? await completeSubmission(options.store, operation, transactionHash)
                        : operation;
                    return {
                        ...receipt,
                        operation: AccountOperation.toRpc(success),
                    };
                }
                if (operation.status === 'pending')
                    return await toTransaction(client, operation);
                const transactionHash = await getSubmittedTransactionHash(options.store, operation);
                if (!transactionHash)
                    return await toTransaction(client, operation);
                const transaction = await next({
                    ...request,
                    params: [transactionHash],
                }, requestOptions);
                if (!transaction || typeof transaction !== 'object')
                    return await toTransaction(client, operation);
                const success = operation.status === 'submitting'
                    ? await completeSubmission(options.store, operation, transactionHash)
                    : operation;
                return {
                    ...transaction,
                    operation: AccountOperation.toRpc(success),
                };
            }
            if (request.method !== 'eth_sendRawTransaction' &&
                request.method !== 'eth_sendRawTransactionSync' &&
                request.method !== 'account_approveRawTransaction' &&
                request.method !== 'account_approveRawTransactionSync')
                return forward();
            const standard = request.method === 'eth_sendRawTransaction' ||
                request.method === 'eth_sendRawTransactionSync';
            const serialized = request.params?.[0];
            if (!isSerializedTempoTransaction(serialized)) {
                if (standard)
                    return forward();
                throw new RpcResponse.InvalidParamsError({
                    message: 'Expected a serialized Tempo configurable account transaction.',
                });
            }
            return await submit({
                client,
                method: request.method,
                next,
                request,
                requestOptions,
                serialized,
                store: options.store,
            });
        },
    });
}
/** Collects approvals and submits a transaction after quorum. @internal */
// biome-ignore lint/correctness/noUnusedVariables: declaration merge
async function submit(options) {
    const transaction = (() => {
        try {
            return deserialize(options.serialized);
        }
        catch (error) {
            if (options.method !== 'eth_sendRawTransaction' &&
                options.method !== 'eth_sendRawTransactionSync')
                throw error;
            return undefined;
        }
    })();
    // A configurable access key (TIP-1111) wraps its owner quorum in a keychain V2 envelope.
    const { signature, userAddress } = (() => {
        const signature = transaction?.signature;
        if (signature?.type === 'keychain' &&
            signature.version === 'v2' &&
            signature.inner.type === 'configurable')
            return { signature: signature.inner, userAddress: signature.userAddress };
        return { signature, userAddress: undefined };
    })();
    if (!transaction || signature?.type !== 'configurable') {
        if (options.method === 'eth_sendRawTransaction' ||
            options.method === 'eth_sendRawTransactionSync') {
            const result = await options.next(options.request, options.requestOptions);
            // Cache after the node accepts the transaction, so only validly signed upgrades are cached.
            // Caching is best-effort: a store failure must not mask an accepted upgrade.
            if (transaction)
                await cacheUpgradeConfig({ store: options.store, transaction }).catch(() => { });
            return result;
        }
        throw new RpcResponse.InvalidParamsError({
            message: 'Expected a configurable account transaction signature.',
        });
    }
    const { signature: _, ...unsigned } = transaction;
    const envelope = TxEnvelopeTempo.from(unsigned);
    const serializedUnsigned = serializeUnsigned(envelope, options.serialized.startsWith(TxEnvelopeTempo.feePayerMagic));
    const blockNumber = await getBlockNumber(options.client, { cacheTime: 0 });
    const config = AccountConfig.from(signature.config);
    const configCommitment = await validateConfig({
        account: signature.account,
        blockNumber,
        client: options.client,
        config,
    });
    const operationHash = AccountOperation.getHash({
        account: signature.account,
        config,
        transaction: serializedUnsigned,
        type: 'transaction',
        userAddress,
    });
    const incoming = signature.signatures.map((signature) => SignatureEnvelope.serialize(signature));
    if (incoming.length === 0)
        throw new RpcResponse.InvalidParamsError({
            message: 'A owner approval envelope must include a signature.',
        });
    const now = Date.now();
    const expiredSubmissionIds = new Set();
    const operation = await OperationStore.update(options.store, operationHash, async (existing) => {
        if (existing && existing.type !== 'transaction')
            throw new OperationStore.InvalidStoreValueError();
        if (existing?.status === 'success')
            return existing;
        if (existing?.status === 'submitting' && existing.expiresAt > now)
            return existing;
        if (existing?.status === 'submitting')
            expiredSubmissionIds.add(existing.submissionId);
        const existingApprovals = existing
            ? await selectApprovals({
                account: signature.account,
                config,
                hash: operationHash,
                approvals: existing.approvals,
            })
            : undefined;
        const approvals = await selectApprovals({
            account: signature.account,
            config,
            hash: operationHash,
            approvals: [...(existingApprovals?.approvals ?? []), ...incoming],
        });
        return AccountOperation.from({
            account: signature.account,
            approvals: approvals.approvals,
            config,
            createdAt: existing?.createdAt ?? now,
            hash: operationHash,
            signatureCount: approvals.signatureCount,
            status: 'pending',
            threshold: approvals.threshold,
            transaction: mergeTransaction(existing?.transaction, serializedUnsigned),
            type: 'transaction',
            updatedAt: now,
            ...(userAddress ? { userAddress } : {}),
            weight: approvals.weight,
        });
    });
    for (const submissionId of expiredSubmissionIds) {
        if (operation.status === 'submitting' &&
            operation.submissionId?.toLowerCase() === submissionId.toLowerCase())
            continue;
        await removeSettledSubmission(options.store, operationHash, submissionId);
    }
    await ConfigStore.write(options.store, {
        address: signature.account,
        chainId: transaction.chainId,
        commitment: configCommitment,
        config,
    });
    // Calls of an access key transaction run as the parent, not the configurable account.
    if (!userAddress)
        await cacheNextConfigs({
            account: signature.account,
            config,
            store: options.store,
            transaction,
        });
    if (operation.type !== 'transaction')
        throw new OperationStore.InvalidStoreValueError();
    if (operation.status === 'success')
        return await submittedResult(options, operation);
    if (operation.status === 'submitting' && operation.expiresAt > Date.now())
        return await submittingResult(options, operation);
    if (operation.weight < operation.threshold)
        return pendingResult(options.method, operation);
    const submissionId = Hex.random(32);
    const timeout = options.request.params?.[1];
    const synchronous = options.method === 'eth_sendRawTransactionSync' ||
        options.method === 'account_approveRawTransactionSync';
    const leaseTtl = synchronous &&
        typeof timeout === 'number' &&
        Number.isSafeInteger(timeout) &&
        timeout >= 0
        ? timeout + submissionTtl
        : submissionTtl;
    const claim = await OperationStore.update(options.store, operationHash, (current) => {
        if (!current || current.type !== 'transaction')
            throw new OperationStore.InvalidStoreValueError();
        if (current.status === 'success')
            return current;
        if (current.status === 'submitting' && current.expiresAt > Date.now())
            return current;
        if (current.weight < current.threshold)
            return current;
        const now = Date.now();
        return AccountOperation.from({
            ...current,
            expiresAt: Math.min(now + leaseTtl, Number.MAX_SAFE_INTEGER),
            status: 'submitting',
            submissionId,
            updatedAt: now,
        });
    });
    if (claim.type !== 'transaction')
        throw new OperationStore.InvalidStoreValueError();
    if (claim.status === 'success')
        return await submittedResult(options, claim);
    if (claim.status === 'pending')
        return pendingResult(options.method, claim);
    if (claim.submissionId !== submissionId)
        return await submittingResult(options, claim);
    const { final, transactionHash: initialTransactionHash } = await (async () => {
        try {
            const blockNumber = await getBlockNumber(options.client, {
                cacheTime: 0,
            });
            await validateConfig({
                account: claim.account,
                blockNumber,
                client: options.client,
                config: claim.config,
            });
            const finalApprovals = await selectApprovals({
                account: claim.account,
                config: claim.config,
                hash: claim.hash,
                approvals: claim.approvals,
            });
            const final = AccountOperation.serializeTransaction(claim, {
                approvals: finalApprovals.selectedApprovals,
            });
            const transactionHash = TxEnvelopeTempo.hash(TxEnvelopeTempo.deserialize(final));
            await OperationStore.writeSubmission(options.store, operationHash, submissionId, final);
            return { final, transactionHash };
        }
        catch (error) {
            await releaseSubmission(options.store, operationHash, submissionId);
            throw error;
        }
    })();
    let transactionHash = initialTransactionHash;
    let result;
    const stopLease = maintainSubmissionLease(options.store, operationHash, submissionId, leaseTtl);
    let leaseStopped = false;
    const stopLeaseOnce = async () => {
        if (leaseStopped)
            return;
        leaseStopped = true;
        await stopLease();
    };
    try {
        try {
            result = await options.next({
                method: options.method === 'eth_sendRawTransaction' ||
                    options.method === 'account_approveRawTransaction'
                    ? 'eth_sendRawTransaction'
                    : 'eth_sendRawTransactionSync',
                params: [final, ...(options.request.params?.slice(1) ?? [])],
            }, options.requestOptions);
            const returnedHash = getTransactionHash(result);
            if (returnedHash.toLowerCase() !== transactionHash.toLowerCase())
                transactionHash = returnedHash;
        }
        catch (error) {
            const submittedHash = await OperationStore.readSubmission(options.store, claim, submissionId);
            const transaction = await (async () => {
                if (!submittedHash)
                    return null;
                try {
                    return await options.next({
                        method: 'eth_getTransactionByHash',
                        params: [submittedHash],
                    });
                }
                catch {
                    return null;
                }
            })();
            await stopLeaseOnce();
            if (!submittedHash || !transaction) {
                await releaseSubmission(options.store, operationHash, submissionId);
                throw error;
            }
            transactionHash = submittedHash;
        }
    }
    finally {
        await stopLeaseOnce();
    }
    const success = await OperationStore.update(options.store, operationHash, (current) => {
        if (!current || current.type !== 'transaction')
            throw new OperationStore.InvalidStoreValueError();
        if (current.status === 'success') {
            if (current.transactionHash?.toLowerCase() !==
                transactionHash.toLowerCase())
                throw new OperationStore.InvalidStoreValueError();
            return current;
        }
        if (current.status !== 'submitting' ||
            current.submissionId !== submissionId)
            throw new OperationStore.InvalidStoreValueError();
        const { expiresAt: _, submissionId: __, ...operation } = current;
        return AccountOperation.from({
            ...operation,
            status: 'success',
            transactionHash,
            updatedAt: Date.now(),
        });
    });
    if (success.type !== 'transaction' || success.status !== 'success')
        throw new OperationStore.InvalidStoreValueError();
    await removeSettledSubmission(options.store, operationHash, submissionId);
    if (options.method === 'eth_sendRawTransactionSync' &&
        result &&
        typeof result === 'object')
        return { ...result, operation: AccountOperation.toRpc(success) };
    return await submittedResult(options, success);
}
/** Collects approvals for a configurable account key authorization. @internal */
// biome-ignore lint/correctness/noUnusedVariables: declaration merge
async function approveKeyAuthorization(options) {
    const value = options.request.params?.[0];
    if (!value || typeof value !== 'object')
        throw new RpcResponse.InvalidParamsError({
            message: 'Expected a configurable account key authorization approval.',
        });
    const approval = await (async () => {
        if ('keyAuthorization' in value) {
            const authorization = (() => {
                try {
                    return KeyAuthorization.fromRpc(value.keyAuthorization);
                }
                catch {
                    throw new RpcResponse.InvalidParamsError({
                        message: 'Invalid configurable account key authorization.',
                    });
                }
            })();
            const signature = authorization.signature;
            if (signature?.type !== 'configurable')
                throw new RpcResponse.InvalidParamsError({
                    message: 'Expected a configurable account key authorization signature.',
                });
            if (!authorization.account ||
                !isAddressEqual(authorization.account, signature.account))
                throw new RpcResponse.InvalidParamsError({
                    message: 'Configurable account key authorization account does not match its signature.',
                });
            const { signature: _, ...unsigned } = authorization;
            const keyAuthorization = KeyAuthorization.serialize(KeyAuthorization.from(unsigned));
            const config = AccountConfig.from(signature.config);
            const hash = AccountOperation.getHash({
                account: signature.account,
                config,
                keyAuthorization,
                type: 'keyAuthorization',
            });
            return {
                account: signature.account,
                approvals: signature.signatures.map((signature) => SignatureEnvelope.serialize(signature)),
                config,
                hash,
                keyAuthorization,
            };
        }
        if ('hash' in value && 'signature' in value) {
            if (typeof value.hash !== 'string' || !Hash.validate(value.hash))
                throw new RpcResponse.InvalidParamsError({
                    message: 'Expected an account operation hash.',
                });
            const operation = await OperationStore.read(options.store, value.hash);
            if (!operation || operation.type !== 'keyAuthorization')
                throw new RpcResponse.InvalidParamsError({
                    message: 'Configurable account key authorization operation was not found.',
                });
            if (operation.status === 'success')
                return { operation };
            const signature = (() => {
                try {
                    return SignatureEnvelope.serialize(SignatureEnvelope.from(value.signature));
                }
                catch {
                    throw new RpcResponse.InvalidParamsError({
                        message: 'Invalid owner signature.',
                    });
                }
            })();
            return {
                account: operation.account,
                approvals: [signature],
                config: operation.config,
                hash: operation.hash,
                keyAuthorization: operation.keyAuthorization,
            };
        }
        throw new RpcResponse.InvalidParamsError({
            message: 'Expected a configurable account key authorization approval.',
        });
    })();
    if ('operation' in approval)
        return AccountOperation.toRpc(approval.operation);
    if (approval.approvals.length === 0)
        throw new RpcResponse.InvalidParamsError({
            message: 'A owner approval envelope must include a signature.',
        });
    const { chainId } = options;
    if (chainId === undefined)
        throw new RpcResponse.InvalidParamsError({
            message: 'A chain ID is required to resolve the downstream client.',
        });
    const blockNumber = await getBlockNumber(options.client, { cacheTime: 0 });
    const commitment = await validateConfig({
        account: approval.account,
        blockNumber,
        client: options.client,
        config: approval.config,
    });
    const now = Date.now();
    const operation = await OperationStore.update(options.store, approval.hash, async (existing) => {
        if (existing && existing.type !== 'keyAuthorization')
            throw new OperationStore.InvalidStoreValueError();
        if (existing?.status === 'success')
            return existing;
        if (existing &&
            (existing.account.toLowerCase() !== approval.account.toLowerCase() ||
                AccountConfig.getCommitment(existing.config).toLowerCase() !==
                    AccountConfig.getCommitment(approval.config).toLowerCase() ||
                existing.keyAuthorization.toLowerCase() !==
                    approval.keyAuthorization.toLowerCase()))
            throw new OperationStore.InvalidStoreValueError();
        const existingApprovals = existing
            ? await selectApprovals({
                account: approval.account,
                approvals: existing.approvals,
                config: approval.config,
                hash: approval.hash,
            })
            : undefined;
        const approvals = await selectApprovals({
            account: approval.account,
            approvals: [
                ...(existingApprovals?.approvals ?? []),
                ...approval.approvals,
            ],
            config: approval.config,
            hash: approval.hash,
        });
        if (existing &&
            approvals.approvals.length === existing.approvals.length &&
            approvals.approvals.every((approval, index) => approval === existing.approvals[index]))
            return existing;
        const pending = {
            account: approval.account,
            approvals: approvals.approvals,
            config: approval.config,
            createdAt: existing?.createdAt ?? now,
            hash: approval.hash,
            keyAuthorization: approval.keyAuthorization,
            signatureCount: approvals.signatureCount,
            threshold: approvals.threshold,
            type: 'keyAuthorization',
            updatedAt: now,
            weight: approvals.weight,
        };
        if (approvals.weight < approvals.threshold)
            return AccountOperation.from({ ...pending, status: 'pending' });
        return AccountOperation.from({
            ...pending,
            keyAuthorization: AccountOperation.serializeKeyAuthorization(approval.keyAuthorization, {
                account: approval.account,
                approvals: approvals.selectedApprovals,
                config: approval.config,
            }),
            status: 'success',
        });
    });
    await ConfigStore.write(options.store, {
        address: approval.account,
        chainId,
        commitment,
        config: approval.config,
    });
    if (operation.type !== 'keyAuthorization')
        throw new OperationStore.InvalidStoreValueError();
    return AccountOperation.toRpc(operation);
}
/** Deserializes a Tempo transaction or throws an RPC parameter error. */
function deserialize(serialized) {
    try {
        return Transaction.deserialize(serialized);
    }
    catch {
        throw new RpcResponse.InvalidParamsError({
            message: 'Invalid serialized Tempo transaction.',
        });
    }
}
/** Validates a config against an observed chain commitment. */
function assertConfig(options) {
    const { account, commitment, config } = options;
    if (config.version === 0n &&
        AccountConfig.getAddress(config).toLowerCase() !== account.toLowerCase())
        throw new RpcResponse.InvalidParamsError({
            message: 'Initial account config does not match the configurable account.',
        });
    if (config.version === 0n && Hex.toBigInt(commitment) === 0n)
        return;
    if (commitment.toLowerCase() !==
        AccountConfig.getCommitment(config).toLowerCase())
        throw new RpcResponse.InvalidParamsError({
            message: `Account config does not match account ${account}.`,
        });
}
/** Reads and validates a config commitment at one block. @internal */
export async function validateConfig(options) {
    const { account, blockNumber, client, config } = options;
    const commitment = await getConfigCommitment(client, {
        account,
        blockNumber,
    });
    assertConfig({ account, commitment, config });
    return commitment;
}
/** Caches candidate configs from valid native update calls. */
// biome-ignore lint/correctness/noUnusedVariables: declaration merge
async function cacheNextConfigs(options) {
    let currentConfig = options.config;
    for (const call of options.transaction.calls) {
        if (!call.to ||
            !isAddressEqual(call.to, Addresses.configurableAccount) ||
            !call.data)
            continue;
        const decoded = (() => {
            try {
                return decodeFunctionData({
                    abi: Abis.configurableAccount,
                    data: call.data,
                });
            }
            catch {
                return undefined;
            }
        })();
        if (decoded?.functionName !== 'updateConfig')
            continue;
        const [current, threshold, owners] = decoded.args;
        const suppliedConfig = (() => {
            try {
                return AccountConfig.from(current);
            }
            catch {
                return undefined;
            }
        })();
        if (!suppliedConfig ||
            AccountConfig.getCommitment(suppliedConfig).toLowerCase() !==
                AccountConfig.getCommitment(currentConfig).toLowerCase())
            continue;
        const config = (() => {
            try {
                return AccountConfig.update(suppliedConfig, { owners, threshold });
            }
            catch {
                return undefined;
            }
        })();
        if (!config)
            continue;
        await ConfigStore.write(options.store, {
            address: options.account,
            chainId: options.transaction.chainId,
            commitment: AccountConfig.getCommitment(config),
            config,
        });
        currentConfig = config;
    }
}
/** Caches the config installed by a root-signed account upgrade. */
// biome-ignore lint/correctness/noUnusedVariables: declaration merge
async function cacheUpgradeConfig(options) {
    const { calls, from, signature } = options.transaction;
    if (!from ||
        !signature ||
        signature.type === 'keychain' ||
        signature.type === 'configurable')
        return;
    // `upgradeAccount` may sit anywhere in a batch; a second one reverts.
    const config = calls
        .map((call) => {
        if (!call.to || !call.data)
            return undefined;
        if (!isAddressEqual(call.to, Addresses.configurableAccount))
            return undefined;
        try {
            const decoded = decodeFunctionData({
                abi: Abis.configurableAccount,
                data: call.data,
            });
            if (decoded.functionName !== 'upgradeAccount')
                return undefined;
            const [threshold, owners] = decoded.args;
            return AccountConfig.fromUpgrade(from, { owners, threshold });
        }
        catch {
            return undefined;
        }
    })
        .find((config) => config !== undefined);
    if (!config)
        return;
    await ConfigStore.write(options.store, {
        address: from,
        chainId: options.transaction.chainId,
        commitment: AccountConfig.getCommitment(config),
        config,
    });
}
/** Validates primitive approvals and translates invalid input into an RPC error. @internal */
export async function selectApprovals(options) {
    try {
        return await AccountOperation.selectApprovals(options);
    }
    catch (error) {
        if (error instanceof AccountOperation.InvalidApprovalError)
            throw new RpcResponse.InvalidParamsError({ message: error.shortMessage });
        throw error;
    }
}
/** Returns an existing successful operation through the requested send method. */
async function submittedResult(options, operation) {
    if (options.method === 'eth_sendRawTransaction' ||
        options.method === 'account_approveRawTransaction')
        return operation.hash;
    if (options.method === 'account_approveRawTransactionSync')
        return AccountOperation.toRpc(operation);
    const timeout = options.request.params?.[1];
    const deadline = Date.now() +
        (typeof timeout === 'number' && timeout >= 0 ? timeout : submissionTtl);
    while (true) {
        const receipt = await options.next({
            method: 'eth_getTransactionReceipt',
            params: [operation.transactionHash],
        }, options.requestOptions);
        if (receipt && typeof receipt === 'object')
            return { ...receipt, operation: AccountOperation.toRpc(operation) };
        if (Date.now() >= deadline)
            throw new Error('Timed out while waiting for the configurable account transaction.');
        await new Promise((resolve) => setTimeout(resolve, pollingInterval));
    }
}
/** Waits for the relay that owns a live submission lease. */
async function submittingResult(options, operation) {
    if (options.method === 'eth_sendRawTransaction' ||
        options.method === 'account_approveRawTransaction')
        return operation.hash;
    const timeout = options.request.params?.[1];
    const deadline = Date.now() +
        (typeof timeout === 'number' && timeout >= 0 ? timeout : submissionTtl);
    while (true) {
        const current = await OperationStore.read(options.store, operation.hash);
        if (!current || current.type !== 'transaction')
            throw new OperationStore.InvalidStoreValueError();
        if (current.status === 'success')
            return await submittedResult(options, current);
        if (current.status === 'pending' || current.expiresAt <= Date.now())
            return await submit(options);
        if (Date.now() >= deadline)
            return pendingResult(options.method, current);
        await new Promise((resolve) => setTimeout(resolve, pollingInterval));
    }
}
/** Returns a pending result for an operation that has not reached quorum. */
function pendingResult(method, operation) {
    if (method === 'eth_sendRawTransaction' ||
        method === 'account_approveRawTransaction')
        return operation.hash;
    if (method === 'account_approveRawTransactionSync')
        return AccountOperation.toRpc(operation);
    return {
        blockHash: null,
        blockNumber: null,
        contractAddress: null,
        cumulativeGasUsed: null,
        effectiveGasPrice: null,
        from: operation.userAddress ?? operation.account,
        gasUsed: null,
        logs: [],
        logsBloom: null,
        operation: AccountOperation.toRpc(operation),
        status: 'pending',
        to: null,
        transactionHash: operation.hash,
        transactionIndex: null,
        type: '0x76',
    };
}
/** Marks a transaction as successful after a lookup proves that it was submitted. */
async function completeSubmission(store, operation, transactionHash) {
    if (operation.status !== 'submitting' || !operation.submissionId)
        throw new OperationStore.InvalidStoreValueError();
    const success = await OperationStore.update(store, operation.hash, (current) => {
        if (!current || current.type !== 'transaction')
            throw new OperationStore.InvalidStoreValueError();
        if (current.status === 'success') {
            if (current.transactionHash?.toLowerCase() !==
                transactionHash.toLowerCase())
                throw new OperationStore.InvalidStoreValueError();
            return current;
        }
        if (current.status !== 'submitting' ||
            current.submissionId !== operation.submissionId)
            throw new OperationStore.InvalidStoreValueError();
        const { expiresAt: _, submissionId: __, transactionHash: ___, ...value } = current;
        return AccountOperation.from({
            ...value,
            status: 'success',
            transactionHash,
            updatedAt: Date.now(),
        });
    });
    await removeSettledSubmission(store, operation.hash, operation.submissionId);
    return success;
}
/** Releases a failed submission lease without discarding collected approvals. */
async function releaseSubmission(store, hash, submissionId) {
    await OperationStore.update(store, hash, (current) => {
        if (!current || current.type !== 'transaction')
            throw new OperationStore.InvalidStoreValueError();
        if (current.status !== 'submitting' ||
            current.submissionId !== submissionId)
            return current;
        const { expiresAt: _, submissionId: __, ...operation } = current;
        return AccountOperation.from({
            ...operation,
            status: 'pending',
            updatedAt: Date.now(),
        });
    });
    await OperationStore.removeSubmission(store, hash, submissionId);
}
/** Removes settled submission data without replacing a successful result with a cleanup error. */
async function removeSettledSubmission(store, hash, submissionId) {
    try {
        await OperationStore.removeSubmission(store, hash, submissionId);
    }
    catch { }
}
/** Preserves or upgrades a fee-payer envelope without removing an existing signature. */
function mergeTransaction(existing, incoming) {
    if (!existing)
        return incoming;
    const existingTransaction = TxEnvelopeTempo.deserialize(existing);
    const incomingTransaction = TxEnvelopeTempo.deserialize(incoming);
    if (!('feePayerSignature' in incomingTransaction))
        return existing;
    if (incomingTransaction.feePayerSignature !== null)
        return incoming;
    if (!('feePayerSignature' in existingTransaction))
        return incoming;
    return existing;
}
/** Returns a synthetic transaction while the downstream transaction is unavailable. */
async function toTransaction(client, operation) {
    const approvals = await (async () => {
        if (operation.status !== 'pending')
            return await AccountOperation.selectApprovals({
                account: operation.account,
                approvals: operation.approvals,
                config: operation.config,
                hash: operation.hash,
            });
        const blockNumber = await getBlockNumber(client, { cacheTime: 0 });
        await validateConfig({
            account: operation.account,
            blockNumber,
            client,
            config: operation.config,
        });
        return await selectApprovals({
            account: operation.account,
            approvals: operation.approvals,
            config: operation.config,
            hash: operation.hash,
        });
    })();
    const current = operation.status === 'pending'
        ? AccountOperation.from({
            ...operation,
            approvals: approvals.approvals,
            signatureCount: approvals.signatureCount,
            threshold: approvals.threshold,
            weight: approvals.weight,
        })
        : operation;
    const serialized = AccountOperation.serializeTransaction(current, {
        approvals: approvals.selectedApprovals,
    });
    const transaction = deserialize(serialized);
    return {
        ...ox_Transaction.toRpc({
            ...transaction,
            blockHash: null,
            blockNumber: null,
            from: operation.userAddress ?? operation.account,
            hash: operation.hash,
            transactionIndex: null,
        }, { pending: true }),
        operation: AccountOperation.toRpc(current),
    };
}
/** Returns the persisted transaction hash for a submitting or successful operation. */
async function getSubmittedTransactionHash(store, operation) {
    if (operation.status === 'success')
        return operation.transactionHash;
    if (operation.status !== 'submitting' || !operation.submissionId)
        throw new OperationStore.InvalidStoreValueError();
    return await OperationStore.readSubmission(store, operation, operation.submissionId);
}
/** Renews a submission lease until the returned cleanup function runs. */
function maintainSubmissionLease(store, hash, submissionId, leaseTtl) {
    let active = true;
    let error;
    let renewal = Promise.resolve();
    const timer = setInterval(() => {
        renewal = renewal.then(async () => {
            if (!active || error)
                return;
            try {
                const operation = await OperationStore.update(store, hash, (current) => {
                    if (!current || current.type !== 'transaction')
                        throw new OperationStore.InvalidStoreValueError();
                    if (current.status !== 'submitting' ||
                        current.submissionId !== submissionId)
                        return current;
                    return AccountOperation.from({
                        ...current,
                        expiresAt: Math.min(Date.now() + leaseTtl, Number.MAX_SAFE_INTEGER),
                        updatedAt: Date.now(),
                    });
                });
                if (operation.type !== 'transaction' ||
                    operation.status !== 'submitting' ||
                    operation.submissionId !== submissionId)
                    throw new OperationStore.InvalidStoreValueError();
            }
            catch (cause) {
                error = cause;
            }
        });
    }, submissionTtl / 2);
    return async () => {
        active = false;
        clearInterval(timer);
        await renewal;
        if (error)
            throw error;
    };
}
/** Canonically serializes an unsigned Tempo transaction. */
function serializeUnsigned(envelope, feePayer) {
    return TxEnvelopeTempo.serialize(envelope, feePayer
        ? envelope.from
            ? { format: 'feePayer', sender: envelope.from }
            : { format: 'feePayer' }
        : {});
}
/** Extracts a transaction hash from an RPC submission result. */
function getTransactionHash(result) {
    if (typeof result === 'string' && Hash.validate(result))
        return result;
    if (result &&
        typeof result === 'object' &&
        'transactionHash' in result &&
        typeof result.transactionHash === 'string' &&
        Hash.validate(result.transactionHash))
        return result.transactionHash;
    throw new Error('Expected transaction hash in account broadcast result.');
}
/** Resolves and validates the chain used by a handled request. */
async function resolveRequestOptions(options) {
    const { request, requestOptions, store } = options;
    const chainId_explicit = requestOptions?.chainId;
    if (chainId_explicit !== undefined &&
        (!Number.isSafeInteger(chainId_explicit) || chainId_explicit <= 0))
        throw new RpcResponse.InvalidParamsError({
            message: 'Expected a valid chain ID.',
        });
    const chainId_request = await resolveRequestChainId(request, store);
    if (chainId_explicit !== undefined &&
        chainId_request !== undefined &&
        chainId_explicit !== chainId_request)
        throw new RpcResponse.InvalidParamsError({
            message: 'Conflicting chain ids.',
        });
    const chainId = chainId_explicit ?? chainId_request;
    if (chainId === undefined)
        return requestOptions;
    return { ...requestOptions, chainId };
}
/** Resolves a chain from request fields, envelopes, or stored operations. */
async function resolveRequestChainId(request, store) {
    const value = request.params?.[0];
    const chainId_body = value && typeof value === 'object' && 'chainId' in value
        ? parseChainId(value.chainId)
        : undefined;
    const chainId_operation = await (async () => {
        if (request.method === 'eth_sendRawTransaction' ||
            request.method === 'eth_sendRawTransactionSync' ||
            request.method === 'account_approveRawTransaction' ||
            request.method === 'account_approveRawTransactionSync') {
            if (!isSerializedTempoTransaction(value))
                return undefined;
            try {
                return parseChainId(Transaction.deserialize(value).chainId);
            }
            catch {
                return undefined;
            }
        }
        if (request.method === 'account_approveKeyAuthorization' &&
            value &&
            typeof value === 'object' &&
            'keyAuthorization' in value) {
            try {
                return parseChainId(KeyAuthorization.fromRpc(value.keyAuthorization).chainId);
            }
            catch {
                return undefined;
            }
        }
        const hash = (() => {
            if (request.method === 'eth_getTransactionByHash' ||
                request.method === 'eth_getTransactionReceipt')
                return value;
            if (request.method === 'account_approveKeyAuthorization' &&
                value &&
                typeof value === 'object' &&
                'hash' in value)
                return value.hash;
            return undefined;
        })();
        if (typeof hash !== 'string' || !Hash.validate(hash))
            return undefined;
        const operation = await OperationStore.read(store, hash);
        if (!operation)
            return undefined;
        if (operation.type === 'transaction')
            return parseChainId(Transaction.deserialize(operation.transaction).chainId);
        return parseChainId(KeyAuthorization.deserialize(operation.keyAuthorization).chainId);
    })();
    if (chainId_body !== undefined &&
        chainId_operation !== undefined &&
        chainId_body !== chainId_operation)
        throw new RpcResponse.InvalidParamsError({
            message: 'Conflicting chain ids.',
        });
    return chainId_body ?? chainId_operation;
}
/** Parses a supported chain ID representation. */
function parseChainId(value) {
    const chainId = (() => {
        if (typeof value === 'number')
            return value;
        if (typeof value === 'bigint')
            return Number(value);
        if (typeof value === 'string' && Hex.validate(value)) {
            try {
                return Hex.toNumber(value);
            }
            catch {
                return undefined;
            }
        }
        return undefined;
    })();
    if (chainId === undefined || !Number.isSafeInteger(chainId) || chainId <= 0)
        return undefined;
    return chainId;
}
/** Checks whether a value is a serialized Tempo transaction. */
function isSerializedTempoTransaction(value) {
    return (typeof value === 'string' &&
        (value.startsWith('0x76') || value.startsWith('0x78')));
}
//# sourceMappingURL=accounts.js.map