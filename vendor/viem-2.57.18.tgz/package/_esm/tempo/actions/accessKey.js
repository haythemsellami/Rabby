import { AccountConfig, AccountOperation, KeyAuthorization, SignatureEnvelope, } from 'ox/tempo';
import { parseAccount } from '../../accounts/utils/parseAccount.js';
import { readContract } from '../../actions/public/readContract.js';
import { watchContractEvent } from '../../actions/public/watchContractEvent.js';
import { sendTransaction } from '../../actions/wallet/sendTransaction.js';
import { sendTransactionSync } from '../../actions/wallet/sendTransactionSync.js';
import { writeContract } from '../../actions/wallet/writeContract.js';
import { writeContractSync } from '../../actions/wallet/writeContractSync.js';
import { MethodNotFoundRpcError, MethodNotSupportedRpcError, } from '../../errors/rpc.js';
import { formatAbiItem } from '../../utils/abi/formatAbiItem.js';
import { parseEventLogs } from '../../utils/abi/parseEventLogs.js';
import { isAddressEqual } from '../../utils/address/isAddressEqual.js';
import * as Abis from '../Abis.js';
import { fromConfig, getKeyAuthorizationSignPayload, resolveAccessKey, signKeyAuthorization, } from '../Account.js';
import * as Addresses from '../Addresses.js';
import { parseApproval } from '../accounts/Signature.js';
import { TempoExecutionError } from '../errors.js';
import * as Hardfork from '../Hardfork.js';
import { formatAmount, formatTime, getFeeToken, withExecutionError, } from '../internal/errors.js';
import { defineCall, isTip20 } from '../internal/utils.js';
import { getConfig } from './accounts.js';
/** @internal */
const signatureTypes = {
    0: 'secp256k1',
    1: 'p256',
    2: 'webAuthn',
    3: 'configurable',
};
/** @internal */
const spendPolicies = {
    true: 'limited',
    false: 'unlimited',
};
/**
 * Authorizes an access key by signing a key authorization and sending a transaction.
 *
 * @example
 * ```ts
 * import { createClient, http } from 'viem'
 * import { tempo } from 'viem/chains'
 * import { Actions, Account } from 'viem/tempo'
 * import { generatePrivateKey } from 'viem/accounts'
 *
 * const account = Account.from({ privateKey: '0x...' })
 * const client = createClient({
 *   account,
 *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
 *   transport: http(),
 * })
 *
 * const accessKey = Account.fromP256(generatePrivateKey(), {
 *   access: account,
 * })
 *
 * const hash = await Actions.accessKey.authorize(client, {
 *   accessKey,
 *   expiry: Math.floor((Date.now() + 30_000) / 1000),
 * })
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 * @returns The transaction hash.
 */
export async function authorize(client, parameters) {
    return authorize.inner(sendTransaction, client, parameters);
}
(function (authorize) {
    /** @internal */
    async function inner(action, client, parameters) {
        const { accessKey, chainId = client.chain?.id, expiry, limits, scopes, witness, ...rest } = parameters;
        const { account: account_ = client.account } = rest;
        if (!account_)
            throw new Error('account is required.');
        if (!chainId)
            throw new Error('chainId is required.');
        const keyAuthorization = await signLocal(client, {
            account: account_,
            accessKey,
            chainId,
            expiry,
            limits,
            scopes,
            witness,
        });
        return (await withExecutionError(action, {
            hints: {
                KeyAlreadyExists: [
                    'This access key is already authorized. Update its spending limits instead.',
                ],
            },
        })(client, {
            ...rest,
            keyAuthorization,
        }));
    }
    authorize.inner = inner;
    function extractEvent(logs) {
        const [log] = parseEventLogs({
            abi: Abis.accountKeychain,
            logs,
            eventName: 'KeyAuthorized',
            strict: true,
        });
        if (!log)
            throw new Error('`KeyAuthorized` event not found.');
        return log;
    }
    authorize.extractEvent = extractEvent;
})(authorize || (authorize = {}));
/**
 * Authorizes an access key and waits for the transaction receipt.
 *
 * @example
 * ```ts
 * import { createClient, http } from 'viem'
 * import { tempo } from 'viem/chains'
 * import { Actions, Account } from 'viem/tempo'
 * import { generatePrivateKey } from 'viem/accounts'
 *
 * const account = Account.from({ privateKey: '0x...' })
 * const client = createClient({
 *   account,
 *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
 *   transport: http(),
 * })
 *
 * const accessKey = Account.fromP256(generatePrivateKey(), {
 *   access: account,
 * })
 *
 * const { receipt, ...result } = await Actions.accessKey.authorizeSync(client, {
 *   accessKey,
 *   expiry: Math.floor((Date.now() + 30_000) / 1000),
 * })
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 * @returns The transaction receipt and event data.
 */
export async function authorizeSync(client, parameters) {
    const { throwOnReceiptRevert = true, ...rest } = parameters;
    const receipt = await authorize.inner(sendTransactionSync, client, {
        ...rest,
        throwOnReceiptRevert,
    });
    if (receipt.status === 'pending')
        return { receipt };
    const { args } = authorize.extractEvent(receipt.logs);
    return {
        ...args,
        receipt,
    };
}
/**
 * Burns a key-authorization witness, invalidating any authorization bound to
 * it before it is submitted onchain.
 *
 * Once burned, an `authorizeKey` call carrying the same `witness` will revert.
 * This lets applications issue a signed authorization offchain (see
 * {@link authorize}) while retaining the ability to revoke it.
 *
 * [TIP-1053](https://tips.sh/1053)
 *
 * @example
 * ```ts
 * import { createClient, http } from 'viem'
 * import { tempo } from 'viem/chains'
 * import { Actions } from 'viem/tempo'
 * import { privateKeyToAccount } from 'viem/accounts'
 *
 * const client = createClient({
 *   account: privateKeyToAccount('0x...'),
 *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
 *   transport: http(),
 * })
 *
 * const hash = await Actions.accessKey.burnWitness(client, {
 *   witness: '0x...',
 * })
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 * @returns The transaction hash.
 */
export async function burnWitness(client, parameters) {
    return burnWitness.inner(writeContract, client, parameters);
}
(function (burnWitness) {
    /** @internal */
    async function inner(action, client, parameters) {
        const { witness, ...rest } = parameters;
        const call = burnWitness.call({ witness });
        return (await withExecutionError(action)(client, {
            ...rest,
            ...call,
        }));
    }
    burnWitness.inner = inner;
    /**
     * Defines a call to the `burnKeyAuthorizationWitness` function.
     *
     * Can be passed as a parameter to:
     * - [`estimateContractGas`](https://viem.sh/docs/contract/estimateContractGas): estimate the gas cost of the call
     * - [`simulateContract`](https://viem.sh/docs/contract/simulateContract): simulate the call
     * - [`sendCalls`](https://viem.sh/docs/actions/wallet/sendCalls): send multiple calls
     *
     * @example
     * ```ts
     * import { createClient, http, walletActions } from 'viem'
     * import { tempo } from 'viem/chains'
     * import { Actions } from 'viem/tempo'
     *
     * const client = createClient({
     *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
     *   transport: http(),
     * }).extend(walletActions)
     *
     * const hash = await client.sendTransaction({
     *   calls: [
     *     Actions.accessKey.burnWitness.call({ witness: '0x...' }),
     *   ],
     * })
     * ```
     *
     * @param args - Arguments.
     * @returns The call.
     */
    function call(args) {
        const { witness } = args;
        return defineCall({
            address: Addresses.accountKeychain,
            abi: Abis.accountKeychain,
            functionName: 'burnKeyAuthorizationWitness',
            args: [witness],
        });
    }
    Object.defineProperty(burnWitness, "call", { configurable: true, enumerable: true, value: call, writable: true });
    function extractEvent(logs) {
        const [log] = parseEventLogs({
            abi: Abis.accountKeychain,
            logs,
            eventName: 'KeyAuthorizationWitnessBurned',
            strict: true,
        });
        if (!log)
            throw new Error('`KeyAuthorizationWitnessBurned` event not found.');
        return log;
    }
    burnWitness.extractEvent = extractEvent;
})(burnWitness || (burnWitness = {}));
/**
 * Burns a key-authorization witness and waits for the transaction receipt.
 *
 * @example
 * ```ts
 * import { createClient, http } from 'viem'
 * import { tempo } from 'viem/chains'
 * import { Actions } from 'viem/tempo'
 * import { privateKeyToAccount } from 'viem/accounts'
 *
 * const client = createClient({
 *   account: privateKeyToAccount('0x...'),
 *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
 *   transport: http(),
 * })
 *
 * const { receipt, ...result } = await Actions.accessKey.burnWitnessSync(client, {
 *   witness: '0x...',
 * })
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 * @returns The transaction receipt and event data.
 */
export async function burnWitnessSync(client, parameters) {
    const { throwOnReceiptRevert = true, ...rest } = parameters;
    const receipt = await burnWitness.inner(writeContractSync, client, {
        ...rest,
        throwOnReceiptRevert,
    });
    if (receipt.status === 'pending')
        return { receipt };
    const { args } = burnWitness.extractEvent(receipt.logs);
    return {
        ...args,
        receipt,
    };
}
/**
 * Gets access key information.
 *
 * @example
 * ```ts
 * import { createClient, http } from 'viem'
 * import { tempo } from 'viem/chains'
 * import { Actions } from 'viem/tempo'
 *
 * const client = createClient({
 *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
 *   transport: http(),
 * })
 *
 * const key = await Actions.accessKey.getMetadata(client, {
 *   account: '0x...',
 *   accessKey: '0x...',
 * })
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 * @returns The key information.
 */
export async function getMetadata(client, parameters) {
    const { account: account_ = client.account, accessKey, ...rest } = parameters;
    if (!account_)
        throw new Error('account is required.');
    const account = parseAccount(account_);
    const result = await withExecutionError(readContract)(client, {
        ...rest,
        account: null,
        ...getMetadata.call({ account: account.address, accessKey }),
    });
    return {
        address: result.keyId,
        keyType: signatureTypes[result.signatureType] ??
            'secp256k1',
        expiry: result.expiry,
        spendPolicy: spendPolicies[`${result.enforceLimits}`],
        isRevoked: result.isRevoked,
    };
}
(function (getMetadata) {
    /**
     * Defines a call to the `getKey` function.
     *
     * @param args - Arguments.
     * @returns The call.
     */
    function call(args) {
        const { account, accessKey } = args;
        return defineCall({
            address: Addresses.accountKeychain,
            abi: Abis.accountKeychain,
            functionName: 'getKey',
            args: [account, resolveAccessKeyAddress(accessKey)],
        });
    }
    Object.defineProperty(getMetadata, "call", { configurable: true, enumerable: true, value: call, writable: true });
})(getMetadata || (getMetadata = {}));
/**
 * Gets the remaining spending limit for a key-token pair.
 *
 * @example
 * ```ts
 * import { createClient, http } from 'viem'
 * import { tempo } from 'viem/chains'
 * import { Actions } from 'viem/tempo'
 *
 * const client = createClient({
 *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
 *   transport: http(),
 * })
 *
 * const { remaining, periodEnd } = await Actions.accessKey.getRemainingLimit(client, {
 *   account: '0x...',
 *   accessKey: '0x...',
 *   token: '0x...',
 * })
 *
 * console.log(remaining, periodEnd)
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 * @returns The remaining spending amount and period end timestamp.
 */
export async function getRemainingLimit(client, parameters) {
    const { account: account_ = client.account, accessKey, token, ...rest } = parameters;
    if (!account_)
        throw new Error('account is required.');
    const account = parseAccount(account_);
    // TODO: remove pre-t3 branch once mainnet is on t3.
    const hardfork = client.chain?.hardfork;
    if (hardfork && Hardfork.lt(hardfork, 't3')) {
        const remaining = await withExecutionError(readContract)(client, {
            ...rest,
            ...getRemainingLimit.call({ account: account.address, accessKey, token }),
        });
        return { remaining, periodEnd: undefined };
    }
    const [remaining, periodEnd] = await withExecutionError(readContract)(client, {
        ...rest,
        ...getRemainingLimit.callWithPeriod({
            account: account.address,
            accessKey,
            token,
        }),
    });
    return { remaining, periodEnd };
}
(function (getRemainingLimit) {
    /**
     * Defines a call to the `getRemainingLimit` function (pre-T3).
     *
     * @param args - Arguments.
     * @returns The call.
     */
    function call(args) {
        const { account, accessKey, token } = args;
        return defineCall({
            address: Addresses.accountKeychain,
            abi: Abis.accountKeychain,
            functionName: 'getRemainingLimit',
            args: [account, resolveAccessKeyAddress(accessKey), token],
        });
    }
    Object.defineProperty(getRemainingLimit, "call", { configurable: true, enumerable: true, value: call, writable: true });
    /**
     * Defines a call to the `getRemainingLimitWithPeriod` function (T3+).
     *
     * @param args - Arguments.
     * @returns The call.
     */
    function callWithPeriod(args) {
        const { account, accessKey, token } = args;
        return defineCall({
            address: Addresses.accountKeychain,
            abi: Abis.accountKeychain,
            functionName: 'getRemainingLimitWithPeriod',
            args: [account, resolveAccessKeyAddress(accessKey), token],
        });
    }
    getRemainingLimit.callWithPeriod = callWithPeriod;
})(getRemainingLimit || (getRemainingLimit = {}));
/**
 * Checks whether a key-authorization witness has been burned for an account.
 *
 * @example
 * ```ts
 * import { createClient, http } from 'viem'
 * import { tempo } from 'viem/chains'
 * import { Actions } from 'viem/tempo'
 *
 * const client = createClient({
 *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
 *   transport: http(),
 * })
 *
 * const isBurned = await Actions.accessKey.isWitnessBurned(client, {
 *   account: '0x...',
 *   witness: '0x...',
 * })
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 * @returns Whether the witness has been burned.
 */
export async function isWitnessBurned(client, parameters) {
    const { account: account_ = client.account, witness, ...rest } = parameters;
    if (!account_)
        throw new Error('account is required.');
    const account = parseAccount(account_);
    return withExecutionError(readContract)(client, {
        ...rest,
        account: null,
        ...isWitnessBurned.call({ account: account.address, witness }),
    });
}
(function (isWitnessBurned) {
    /**
     * Defines a call to the `isKeyAuthorizationWitnessBurned` function.
     *
     * @param args - Arguments.
     * @returns The call.
     */
    function call(args) {
        const { account, witness } = args;
        return defineCall({
            address: Addresses.accountKeychain,
            abi: Abis.accountKeychain,
            functionName: 'isKeyAuthorizationWitnessBurned',
            args: [account, witness],
        });
    }
    Object.defineProperty(isWitnessBurned, "call", { configurable: true, enumerable: true, value: call, writable: true });
})(isWitnessBurned || (isWitnessBurned = {}));
/**
 * Revokes an authorized access key.
 *
 * @example
 * ```ts
 * import { createClient, http } from 'viem'
 * import { tempo } from 'viem/chains'
 * import { Actions } from 'viem/tempo'
 * import { privateKeyToAccount } from 'viem/accounts'
 *
 * const client = createClient({
 *   account: privateKeyToAccount('0x...'),
 *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
 *   transport: http(),
 * })
 *
 * const hash = await Actions.accessKey.revoke(client, {
 *   accessKey: '0x...',
 * })
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 * @returns The transaction hash.
 */
export async function revoke(client, parameters) {
    return revoke.inner(writeContract, client, parameters);
}
(function (revoke) {
    /** @internal */
    async function inner(action, client, parameters) {
        const { accessKey, ...rest } = parameters;
        const call = revoke.call({ accessKey });
        return (await withExecutionError(action)(client, {
            ...rest,
            ...call,
        }));
    }
    revoke.inner = inner;
    /**
     * Defines a call to the `revokeKey` function.
     *
     * Can be passed as a parameter to:
     * - [`estimateContractGas`](https://viem.sh/docs/contract/estimateContractGas): estimate the gas cost of the call
     * - [`simulateContract`](https://viem.sh/docs/contract/simulateContract): simulate the call
     * - [`sendCalls`](https://viem.sh/docs/actions/wallet/sendCalls): send multiple calls
     *
     * @example
     * ```ts
     * import { createClient, http, walletActions } from 'viem'
     * import { tempo } from 'viem/chains'
     * import { Actions } from 'viem/tempo'
     *
     * const client = createClient({
     *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
     *   transport: http(),
     * }).extend(walletActions)
     *
     * const hash = await client.sendTransaction({
     *   calls: [
     *     Actions.accessKey.revoke.call({ accessKey: '0x...' }),
     *   ],
     * })
     * ```
     *
     * @param args - Arguments.
     * @returns The call.
     */
    function call(args) {
        const { accessKey } = args;
        return defineCall({
            address: Addresses.accountKeychain,
            abi: Abis.accountKeychain,
            functionName: 'revokeKey',
            args: [resolveAccessKeyAddress(accessKey)],
        });
    }
    Object.defineProperty(revoke, "call", { configurable: true, enumerable: true, value: call, writable: true });
    function extractEvent(logs) {
        const [log] = parseEventLogs({
            abi: Abis.accountKeychain,
            logs,
            eventName: 'KeyRevoked',
            strict: true,
        });
        if (!log)
            throw new Error('`KeyRevoked` event not found.');
        return log;
    }
    revoke.extractEvent = extractEvent;
})(revoke || (revoke = {}));
/**
 * Revokes an authorized access key and waits for the transaction receipt.
 *
 * @example
 * ```ts
 * import { createClient, http } from 'viem'
 * import { tempo } from 'viem/chains'
 * import { Actions } from 'viem/tempo'
 * import { privateKeyToAccount } from 'viem/accounts'
 *
 * const client = createClient({
 *   account: privateKeyToAccount('0x...'),
 *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
 *   transport: http(),
 * })
 *
 * const result = await Actions.accessKey.revokeSync(client, {
 *   accessKey: '0x...',
 * })
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 * @returns The transaction receipt and event data.
 */
export async function revokeSync(client, parameters) {
    const { throwOnReceiptRevert = true, ...rest } = parameters;
    const receipt = await revoke.inner(writeContractSync, client, {
        ...rest,
        throwOnReceiptRevert,
    });
    if (receipt.status === 'pending')
        return { receipt };
    const { args } = revoke.extractEvent(receipt.logs);
    return {
        ...args,
        receipt,
    };
}
/**
 * Prepares a key authorization for signing.
 *
 * @example
 * ```ts
 * const authorization = await Actions.accessKey.prepareAuthorization(client, {
 *   account,
 *   accessKey,
 * })
 * const keyAuthorization = await Actions.accessKey.signAuthorization(
 *   client,
 *   authorization,
 * )
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 * @returns Prepared key authorization parameters.
 */
export async function prepareAuthorization(client, parameters) {
    const { chainId = client.chain?.id } = parameters;
    const account_ = parameters.account ?? client.account;
    if (!account_)
        throw new Error('account is required.');
    if (!chainId)
        throw new Error('chainId is required.');
    const parsed = parseAccount(account_);
    const configurableState = await (async () => {
        if ('configurable' in parameters)
            return parameters.configurable;
        if (parsed.source !== 'configurable')
            return undefined;
        const account = parsed;
        if (!account.config)
            throw new Error('An account config is required to prepare a key authorization.');
        return { config: account.config };
    })();
    const authorizationSignPayload = getKeyAuthorizationSignPayload(parsed, {
        ...parameters,
        chainId: BigInt(chainId),
        key: parameters.accessKey,
    });
    const signPayload = parsed.source === 'configurable' && configurableState
        ? AccountConfig.getSignPayload({
            account: parsed.address,
            config: configurableState.config,
            payload: authorizationSignPayload,
        })
        : authorizationSignPayload;
    return {
        ...parameters,
        account: parsed,
        chainId,
        configurable: configurableState,
        signPayload,
    };
}
/**
 * Saves a signed key authorization to a relay with key authorization storage.
 *
 * The relay attaches the authorization to the access key's next transaction until
 * the key is active onchain. Use this for authorizations signed outside
 * {@link signAuthorization}, such as on another device. Requires a relay running the
 * `Relay.keyAuthorization` plugin.
 *
 * @example
 * ```ts
 * import { createClient, http } from 'viem'
 * import { tempo } from 'viem/chains'
 * import { Actions, withRelay } from 'viem/tempo'
 *
 * const client = createClient({
 *   chain: tempo,
 *   transport: withRelay(http(), http('https://relay.example.com'), {
 *     keyAuthorization: true,
 *   }),
 * })
 *
 * await Actions.accessKey.saveAuthorization(client, {
 *   keyAuthorization,
 * })
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 */
export async function saveAuthorization(client, parameters) {
    const { keyAuthorization } = parameters;
    await client.request({
        method: 'relay_saveKeyAuthorization',
        params: [KeyAuthorization.toRpc(keyAuthorization)],
    });
}
export async function signAuthorization(client, parameters) {
    const coordinated = ('hash' in parameters && parameters.hash) ||
        ('owner' in parameters && parameters.owner);
    if (coordinated) {
        const parameters_ = parameters;
        const owner_ = parameters_.owner;
        if (!owner_ || typeof owner_ === 'string')
            throw new Error('A local owner account is required to approve a configurable account key authorization.');
        const owner = parseAccount(owner_);
        const sign = owner.sign;
        if (!sign)
            throw new Error('A local owner account is required to approve a configurable account key authorization.');
        const request = await (async () => {
            if ('hash' in parameters_ && parameters_.hash) {
                const signature = SignatureEnvelope.serialize(SignatureEnvelope.from(await sign({ hash: parameters_.hash })));
                return { hash: parameters_.hash, signature };
            }
            const { account: account_, owner: _, ...authorization } = parameters_;
            const address = typeof account_ === 'string' ? account_ : account_.address;
            const config = await (async () => {
                if (typeof account_ !== 'string' && account_.config)
                    return account_.config;
                const config = await getConfig(client, { address });
                if (config)
                    return config;
                throw new Error(`No current account config is cached for account ${address}. Provide the current config.`);
            })();
            const account = (() => {
                if (config.version !== 0n)
                    return fromConfig({ address, ...config });
                const { version: _, ...initialConfig } = config;
                return fromConfig({ address: 'infer', ...initialConfig });
            })();
            if (!isAddressEqual(account.address, address))
                throw new Error('Initial account config does not match the account.');
            const prepared = await prepareAuthorization(client, {
                ...authorization,
                account,
            });
            const signature = SignatureEnvelope.serialize(SignatureEnvelope.from(await sign({ hash: prepared.signPayload })));
            const { accessKey, chainId, expiry, limits, scopes, witness } = prepared;
            const { accessKeyAddress, keyType: type } = resolveAccessKey(accessKey);
            const keyAuthorization = KeyAuthorization.from({
                account: account.address,
                address: accessKeyAddress,
                chainId: BigInt(chainId),
                signature: SignatureEnvelope.from({
                    account: account.address,
                    config,
                    signatures: [parseApproval(signature)],
                }),
                type,
                ...(witness ? { witness } : {}),
                expiry,
                limits,
                scopes,
            });
            return { keyAuthorization: KeyAuthorization.toRpc(keyAuthorization) };
        })();
        const operation = await client.request({
            method: 'account_approveKeyAuthorization',
            params: [request],
        });
        const operation_ = AccountOperation.fromRpc(operation);
        const keyAuthorization = KeyAuthorization.deserialize(await (async () => {
            if (operation_.status === 'success')
                return operation_.keyAuthorization;
            const approvals = await AccountOperation.selectApprovals({
                account: operation_.account,
                approvals: operation_.approvals,
                config: operation_.config,
                hash: operation_.hash,
            });
            return AccountOperation.serializeKeyAuthorization(operation_.keyAuthorization, {
                account: operation_.account,
                approvals: approvals.selectedApprovals.length > 0
                    ? approvals.selectedApprovals
                    : approvals.approvals.slice(0, 1),
                config: operation_.config,
            });
        })());
        if (!keyAuthorization.signature)
            throw new Error('Expected a signed configurable account key authorization.');
        return {
            ...keyAuthorization,
            hash: operation_.hash,
            operation: operation_,
            status: operation_.status,
        };
    }
    const keyAuthorization = await signLocal(client, parameters);
    // Relays with key authorization storage attach it to the access key's next transaction.
    if (client.transport.keyAuthorization)
        await saveAuthorization(client, { keyAuthorization }).catch((error) => {
            // Remote relays without key authorization storage do not expose this method.
            if (error instanceof MethodNotFoundRpcError ||
                error instanceof MethodNotSupportedRpcError)
                return;
            throw error;
        });
    return keyAuthorization;
}
/** Signs a key authorization locally without saving it to a relay. */
async function signLocal(client, parameters) {
    const prepared = ('signPayload' in parameters
        ? parameters
        : await prepareAuthorization(client, parameters));
    const { accessKey, account: account_, chainId, configurable: configurableState, signPayload: _, ...rest } = prepared;
    return signKeyAuthorization(account_, {
        chainId: BigInt(chainId),
        key: accessKey,
        configurable: configurableState,
        ...rest,
    });
}
/**
 * Updates the spending limit for a specific token on an authorized access key.
 *
 * @example
 * ```ts
 * import { createClient, http } from 'viem'
 * import { tempo } from 'viem/chains'
 * import { Actions } from 'viem/tempo'
 * import { privateKeyToAccount } from 'viem/accounts'
 *
 * const client = createClient({
 *   account: privateKeyToAccount('0x...'),
 *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
 *   transport: http(),
 * })
 *
 * const hash = await Actions.accessKey.updateLimit(client, {
 *   accessKey: '0x...',
 *   token: '0x...',
 *   limit: 1000000000000000000n,
 * })
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 * @returns The transaction hash.
 */
export async function updateLimit(client, parameters) {
    return updateLimit.inner(writeContract, client, parameters);
}
(function (updateLimit) {
    /** @internal */
    async function inner(action, client, parameters) {
        const { accessKey, token, limit, ...rest } = parameters;
        const call = updateLimit.call({ accessKey, token, limit });
        return (await withExecutionError(action)(client, {
            ...rest,
            ...call,
        }));
    }
    updateLimit.inner = inner;
    /**
     * Defines a call to the `updateSpendingLimit` function.
     *
     * Can be passed as a parameter to:
     * - [`estimateContractGas`](https://viem.sh/docs/contract/estimateContractGas): estimate the gas cost of the call
     * - [`simulateContract`](https://viem.sh/docs/contract/simulateContract): simulate the call
     * - [`sendCalls`](https://viem.sh/docs/actions/wallet/sendCalls): send multiple calls
     *
     * @example
     * ```ts
     * import { createClient, http, walletActions } from 'viem'
     * import { tempo } from 'viem/chains'
     * import { Actions } from 'viem/tempo'
     *
     * const client = createClient({
     *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
     *   transport: http(),
     * }).extend(walletActions)
     *
     * const hash = await client.sendTransaction({
     *   calls: [
     *     Actions.accessKey.updateLimit.call({
     *       accessKey: '0x...',
     *       token: '0x...',
     *       limit: 1000000000000000000n,
     *     }),
     *   ],
     * })
     * ```
     *
     * @param args - Arguments.
     * @returns The call.
     */
    function call(args) {
        const { accessKey, token, limit } = args;
        return defineCall({
            address: Addresses.accountKeychain,
            abi: Abis.accountKeychain,
            functionName: 'updateSpendingLimit',
            args: [resolveAccessKeyAddress(accessKey), token, limit],
        });
    }
    Object.defineProperty(updateLimit, "call", { configurable: true, enumerable: true, value: call, writable: true });
    function extractEvent(logs) {
        const [log] = parseEventLogs({
            abi: Abis.accountKeychain,
            logs,
            eventName: 'SpendingLimitUpdated',
            strict: true,
        });
        if (!log)
            throw new Error('`SpendingLimitUpdated` event not found.');
        return log;
    }
    updateLimit.extractEvent = extractEvent;
})(updateLimit || (updateLimit = {}));
/**
 * Updates the spending limit and waits for the transaction receipt.
 *
 * @example
 * ```ts
 * import { createClient, http } from 'viem'
 * import { tempo } from 'viem/chains'
 * import { Actions } from 'viem/tempo'
 * import { privateKeyToAccount } from 'viem/accounts'
 *
 * const client = createClient({
 *   account: privateKeyToAccount('0x...'),
 *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
 *   transport: http(),
 * })
 *
 * const result = await Actions.accessKey.updateLimitSync(client, {
 *   accessKey: '0x...',
 *   token: '0x...',
 *   limit: 1000000000000000000n,
 * })
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 * @returns The transaction receipt and event data.
 */
export async function updateLimitSync(client, parameters) {
    const { throwOnReceiptRevert = true, ...rest } = parameters;
    const receipt = await updateLimit.inner(writeContractSync, client, {
        ...rest,
        throwOnReceiptRevert,
    });
    if (receipt.status === 'pending')
        return { receipt };
    const { args } = updateLimit.extractEvent(receipt.logs);
    return {
        account: args.account,
        publicKey: args.publicKey,
        token: args.token,
        limit: args.newLimit,
        receipt,
    };
}
/**
 * Watches for key-authorization witness events.
 *
 * Emitted when a key is authorized with a `witness` (see {@link authorize}).
 *
 * @example
 * ```ts
 * import { createClient, http } from 'viem'
 * import { tempo } from 'viem/chains'
 * import { Actions } from 'viem/tempo'
 *
 * const client = createClient({
 *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
 *   transport: http(),
 * })
 *
 * const unwatch = Actions.accessKey.watchWitness(client, {
 *   onWitness: (args, log) => {
 *     console.log('Witness used:', args)
 *   },
 * })
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 * @returns A function to unsubscribe from the event.
 */
export function watchWitness(client, parameters) {
    const { onWitness, ...rest } = parameters;
    return watchContractEvent(client, {
        ...rest,
        address: Addresses.accountKeychain,
        abi: Abis.accountKeychain,
        eventName: 'KeyAuthorizationWitness',
        onLogs: (logs) => {
            for (const log of logs)
                onWitness(log.args, log);
        },
        strict: true,
    });
}
/**
 * Watches for key-authorization witness burned events.
 *
 * Emitted when a witness is burned (see {@link burnWitness}).
 *
 * @example
 * ```ts
 * import { createClient, http } from 'viem'
 * import { tempo } from 'viem/chains'
 * import { Actions } from 'viem/tempo'
 *
 * const client = createClient({
 *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
 *   transport: http(),
 * })
 *
 * const unwatch = Actions.accessKey.watchWitnessBurned(client, {
 *   onBurned: (args, log) => {
 *     console.log('Witness burned:', args)
 *   },
 * })
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 * @returns A function to unsubscribe from the event.
 */
export function watchWitnessBurned(client, parameters) {
    const { onBurned, ...rest } = parameters;
    return watchContractEvent(client, {
        ...rest,
        address: Addresses.accountKeychain,
        abi: Abis.accountKeychain,
        eventName: 'KeyAuthorizationWitnessBurned',
        onLogs: (logs) => {
            for (const log of logs)
                onBurned(log.args, log);
        },
        strict: true,
    });
}
/**
 * Verifies that a keychain signature was produced by an active access key
 * for the expected account.
 *
 * By default (`admin: true`), returns `true` only if the signature was
 * produced by the account's root key. Set `admin: false` to accept any active
 * access key.
 *
 * Returns `false` for account mismatches, unknown, revoked, or expired
 * access keys. [TIP-1049](https://tips.sh/1049)
 *
 * The key of an account with a config commitment (a configurable or upgraded
 * account) passes neither mode, and an inner signature type other than the stored key
 * type returns `false`. Configurable access keys (TIP-1111) revert as an
 * invalid format; verify them with `verifyHash` from `viem/actions` instead.
 *
 * @example
 * ```ts
 * import { createClient, http } from 'viem'
 * import { tempo } from 'viem/chains'
 * import { Actions } from 'viem/tempo'
 *
 * const client = createClient({
 *   chain: tempo.extend({ feeToken: '0x20c0000000000000000000000000000000000001' }),
 *   transport: http(),
 * })
 *
 * const valid = await Actions.accessKey.verifyHash(client, {
 *   account: '0x...',
 *   hash: '0x...',
 *   signature: '0x...',
 * })
 * ```
 *
 * @param client - Client.
 * @param parameters - Parameters.
 * @returns Whether the keychain signature is valid for the account.
 */
export async function verifyHash(client, parameters) {
    const { account, admin, hash, signature, ...rest } = parameters;
    return withExecutionError(readContract)(client, {
        ...rest,
        ...verifyHash.call({ account, admin, hash, signature }),
    });
}
(function (verifyHash) {
    /**
     * Defines a call to `verifyKeychain` or `verifyKeychainAdmin` on the
     * Signature Verifier precompile (controlled by `admin`).
     *
     * @param args - Arguments.
     * @returns The call.
     */
    function call(args) {
        const { account, admin = true, hash, signature } = args;
        return defineCall({
            address: Addresses.signatureVerifier,
            abi: Abis.signatureVerifier,
            functionName: admin ? 'verifyKeychainAdmin' : 'verifyKeychain',
            args: [account, hash, signature],
        });
    }
    Object.defineProperty(verifyHash, "call", { configurable: true, enumerable: true, value: call, writable: true });
})(verifyHash || (verifyHash = {}));
/** @internal */
function resolveAccessKeyAddress(accessKey) {
    if (typeof accessKey === 'string')
        return accessKey;
    return accessKey.accessKeyAddress;
}
/** Thrown when an access key fails an `AccountKeychain` check. */
export class AccessKeyError extends TempoExecutionError {
    constructor(parameters, options = {}) {
        const { account, accessKey } = parameters;
        super(parameters, {
            shortMessage: `Access key "${accessKey}" failed: ${parameters.error.message}`,
            ...options,
            details: { account, 'access key': accessKey, ...options.details },
            docsPath: '/tempo/guides/access-keys/manage',
            name: options.name ?? 'AccessKeyError',
        });
        /** Root account that owns the access key. */
        Object.defineProperty(this, "account", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Access key address. */
        Object.defineProperty(this, "accessKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.account = account;
        this.accessKey = accessKey;
    }
}
/** Thrown when a transfer, approval, or fee payment exceeds an access key's spending limit. */
export class AccessKeySpendingLimitExceededError extends AccessKeyError {
    constructor(parameters) {
        const { amount, decimals, fee, periodEnd, remaining, token } = parameters;
        super(parameters, {
            details: {
                token,
                amount: formatAmount(amount, decimals),
                remaining: formatAmount(remaining, decimals),
                'exceeded by': amount !== undefined && remaining !== undefined
                    ? formatAmount(amount - remaining, decimals)
                    : undefined,
                'resets at': formatTime(periodEnd),
            },
            name: 'AccessKeySpendingLimitExceededError',
            shortMessage: `Access key "${parameters.accessKey}" exceeded its spending limit${token ? ` for token "${token}"` : ''}${fee ? ' while paying fees' : ''}.`,
        });
        /** Amount the call tried to spend, when known. */
        Object.defineProperty(this, "amount", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Token decimals, when known. */
        Object.defineProperty(this, "decimals", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Whether the fee payment, rather than the call, exceeded the limit. */
        Object.defineProperty(this, "fee", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** End of the current period (Unix seconds) for periodic limits, when known. */
        Object.defineProperty(this, "periodEnd", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Remaining limit for `token`, when known. */
        Object.defineProperty(this, "remaining", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Token the limit applies to, when known. */
        Object.defineProperty(this, "token", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.amount = amount;
        this.decimals = decimals;
        this.fee = fee;
        this.periodEnd = periodEnd;
        this.remaining = remaining;
        this.token = token;
    }
}
/** Thrown when a transaction is signed with an expired access key. */
export class AccessKeyExpiredError extends AccessKeyError {
    constructor(parameters) {
        super(parameters, {
            details: { 'expired at': formatTime(parameters.expiry) },
            name: 'AccessKeyExpiredError',
            shortMessage: `Access key "${parameters.accessKey}" has expired.`,
        });
        /** Expiry (Unix seconds), when known. */
        Object.defineProperty(this, "expiry", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.expiry = parameters.expiry;
    }
}
/** Thrown when an access key's scopes do not allow a call. */
export class AccessKeyCallNotAllowedError extends AccessKeyError {
    constructor(parameters) {
        const { selector, target } = parameters;
        super(parameters, {
            details: { target, selector },
            name: 'AccessKeyCallNotAllowedError',
            shortMessage: `Access key "${parameters.accessKey}" is not allowed to make this call.`,
        });
        /** Function selector of the rejected call, when known. */
        Object.defineProperty(this, "selector", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Target of the rejected call, when known. */
        Object.defineProperty(this, "target", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.selector = selector;
        this.target = target;
    }
}
/** Thrown when authorizing an access key that is already authorized. */
export class AccessKeyAlreadyExistsError extends AccessKeyError {
    constructor(parameters) {
        const { expiry, limited } = parameters;
        super(parameters, {
            details: {
                expires: formatTime(expiry),
                'spending limits': limited === undefined ? undefined : limited ? 'enforced' : 'none',
            },
            name: 'AccessKeyAlreadyExistsError',
            shortMessage: `Access key "${parameters.accessKey}" is already authorized on account "${parameters.account}".`,
        });
        /** Expiry (Unix seconds) of the existing key, when known. */
        Object.defineProperty(this, "expiry", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Whether the existing key enforces spending limits, when known. */
        Object.defineProperty(this, "limited", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.expiry = expiry;
        this.limited = limited;
    }
}
/** Thrown when an access key signs with a different key type than it was authorized with. */
export class AccessKeySignatureTypeMismatchError extends AccessKeyError {
    constructor(parameters) {
        const [expected, actual] = (parameters.error.args ?? []).map((type) => signatureTypes[Number(type)]);
        super(parameters, {
            details: { expected, actual },
            name: 'AccessKeySignatureTypeMismatchError',
            shortMessage: `Access key "${parameters.accessKey}" signed with a ${actual ?? 'different'} key, but was authorized as a ${expected ?? 'different'} key.`,
        });
        /** Key type the access key was authorized with. */
        Object.defineProperty(this, "expected", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Key type of the signature. */
        Object.defineProperty(this, "actual", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.expected = expected;
        this.actual = actual;
    }
}
/** Thrown when authorizing an access key with an expiry that has passed or is too soon. */
export class AccessKeyExpiryInPastError extends AccessKeyError {
    constructor(parameters) {
        const { expiry, minimum } = parameters;
        super(parameters, {
            details: { expiry: formatTime(expiry), minimum: formatTime(minimum) },
            name: 'AccessKeyExpiryInPastError',
            shortMessage: `Access key "${parameters.accessKey}" expiry must be later${minimum ? ` than ${formatTime(minimum)}` : ''}.`,
        });
        /** Requested expiry (Unix seconds), when known. */
        Object.defineProperty(this, "expiry", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Earliest allowed expiry (Unix seconds), when known. */
        Object.defineProperty(this, "minimum", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.expiry = expiry;
        this.minimum = minimum;
    }
}
const keychain = {
    address: Addresses.accountKeychain,
    abi: Abis.accountKeychain,
};
/** Signer and key for errors raised while validating the signing access key. */
function getSigner(context) {
    const { call, parameters, signer } = context;
    if (!signer?.accessKey)
        return undefined;
    // Key management calls and authorizations of another key fail about that key, not the signer.
    if (call && isAddressEqual(call.address, Addresses.accountKeychain))
        return undefined;
    const authorized = parameters.keyAuthorization?.address;
    if (authorized && !isAddressEqual(authorized, signer.accessKey))
        return undefined;
    return {
        ...context.base,
        account: signer.address,
        accessKey: signer.accessKey,
    };
}
/** Fee payer and key for fee payment errors. External fee payers cannot be resolved. */
function getFeePayer(context) {
    const { feePayer } = context.parameters;
    if (typeof feePayer !== 'object')
        return undefined;
    const account = parseAccount(feePayer);
    if (account.source !== 'accessKey' || !('accessKeyAddress' in account))
        return undefined;
    return {
        ...context.base,
        account: account.address,
        accessKey: account.accessKeyAddress,
    };
}
/** Account and key for errors raised while authorizing a key. */
function getAuthorization(context) {
    const { call, parameters, signer } = context;
    const accessKey = parameters.keyAuthorization?.address ??
        call?.arg('keyId');
    if (!signer || !accessKey)
        return undefined;
    return { ...context.base, account: signer.address, accessKey };
}
/** @internal */
export const errorResolvers = {
    // Fallback for `AccountKeychain` errors without a specific resolver below.
    ...Object.fromEntries(Abis.accountKeychain.flatMap((item) => item.type === 'error'
        ? [
            [
                formatAbiItem(item),
                (context) => {
                    const parameters = getSigner(context);
                    return parameters && new AccessKeyError(parameters);
                },
            ],
        ]
        : [])),
    'CallNotAllowed()': (context) => {
        const parameters = getSigner(context);
        if (!parameters)
            return undefined;
        return new AccessKeyCallNotAllowedError({
            ...parameters,
            selector: context.parameters.data?.slice(0, 10),
            target: context.call?.address ?? context.parameters.to,
        });
    },
    'ExpiryInPast()': (context) => {
        const parameters = getAuthorization(context);
        if (!parameters)
            return undefined;
        const [, expiry, minimum] = /expiry (\d+) <= min allowed (\d+)/.exec(context.details) ?? [];
        const requested = context.parameters.keyAuthorization?.expiry ??
            context.call?.arg('expiry') ??
            context.call?.arg('config')?.expiry;
        return new AccessKeyExpiryInPastError({
            ...parameters,
            expiry: expiry
                ? BigInt(expiry)
                : requested === undefined || requested === null
                    ? undefined
                    : BigInt(requested),
            minimum: minimum ? BigInt(minimum) : undefined,
        });
    },
    'KeyAlreadyExists()': async (context) => {
        const parameters = getAuthorization(context);
        if (!parameters)
            return undefined;
        const [key] = await context.read([
            {
                ...keychain,
                functionName: 'getKey',
                args: [parameters.account, parameters.accessKey],
            },
        ]);
        return new AccessKeyAlreadyExistsError({
            ...parameters,
            expiry: key?.result?.expiry,
            limited: key?.result?.enforceLimits,
        });
    },
    'KeyExpired()': async (context) => {
        const parameters = getSigner(context);
        if (!parameters)
            return undefined;
        const [key] = await context.read([
            {
                ...keychain,
                functionName: 'getKey',
                args: [parameters.account, parameters.accessKey],
            },
        ]);
        return new AccessKeyExpiredError({
            ...parameters,
            expiry: key?.result?.expiry,
        });
    },
    'SignatureTypeMismatch(uint8,uint8)': (context) => {
        const parameters = getSigner(context) ?? getAuthorization(context);
        return parameters && new AccessKeySignatureTypeMismatchError(parameters);
    },
    'SpendingLimitExceeded()': async (context) => {
        // Without revert data, the fee payment exceeded the limit.
        const fee = context.validation;
        const parameters = fee && context.parameters.feePayer
            ? getFeePayer(context)
            : getSigner(context);
        if (!parameters)
            return undefined;
        const token = fee
            ? getFeeToken(context)
            : isTip20(context.call?.address)
                ? context.call.address
                : undefined;
        if (!token)
            return new AccessKeySpendingLimitExceededError({
                ...parameters,
                fee,
                hints: fee
                    ? [...parameters.hints, 'Pay fees with another token.']
                    : parameters.hints,
            });
        const args = [parameters.account, parameters.accessKey, token];
        const [withPeriod, legacy, decimals] = await context.read([
            // `getRemainingLimitWithPeriod` is T3+; `getRemainingLimit` covers earlier hardforks.
            { ...keychain, functionName: 'getRemainingLimitWithPeriod', args },
            { ...keychain, functionName: 'getRemainingLimit', args },
            { address: token, abi: Abis.tip20, functionName: 'decimals' },
        ]);
        return new AccessKeySpendingLimitExceededError({
            ...parameters,
            amount: fee ? undefined : context.call?.arg('amount'),
            decimals: decimals?.result,
            fee,
            periodEnd: withPeriod?.result?.[1] || undefined,
            remaining: withPeriod?.result?.[0] ?? legacy?.result,
            token,
        });
    },
};
//# sourceMappingURL=accessKey.js.map