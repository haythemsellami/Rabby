import * as Address from 'ox/Address';
import * as Hex from 'ox/Hex';
import * as P256 from 'ox/P256';
import * as PublicKey from 'ox/PublicKey';
import * as Secp256k1 from 'ox/Secp256k1';
import * as Signature from 'ox/Signature';
import { AccountConfig, Channel, KeyAuthorization, SignatureEnvelope, SignaturePreAuthorized, } from 'ox/tempo';
import * as WebAuthnP256 from 'ox/WebAuthnP256';
import * as WebCryptoP256 from 'ox/WebCryptoP256';
import { parseAccount } from '../accounts/utils/parseAccount.js';
import { BaseError } from '../errors/base.js';
import { hashAuthorization } from '../utils/authorization/hashAuthorization.js';
import { keccak256 } from '../utils/hash/keccak256.js';
import { hashMessage } from '../utils/signature/hashMessage.js';
import { hashTypedData } from '../utils/signature/hashTypedData.js';
import { parseApproval } from './accounts/Signature.js';
import * as Transaction from './Transaction.js';
/**
 * Rebuilds a configurable account (TIP-1107) from the value of {@link serialize},
 * such as one read from storage, without a request.
 *
 * Passkeys among `credentials` sign as owners when their public key derives an
 * owner's address; others are ignored. A version-zero config must derive
 * `address`, and a later version keeps `address`.
 *
 * @example
 * ```ts
 * import { Account } from 'viem/tempo'
 *
 * const account = Account.deserialize(JSON.parse(localStorage.getItem('account')!), {
 *   credentials: [credential],
 * })
 * ```
 *
 * @param value Serialized account.
 * @param options Options.
 * @returns Configurable account.
 */
export function deserialize(value, options = {}) {
    const { address, config } = value;
    const { credentials = [], getFn } = options;
    if (!config)
        return fromConfig(address);
    const owners = config.owners.map(({ owner, weight }) => {
        const credential = credentials.find((credential) => Address.isEqual(Address.fromPublicKey(PublicKey.fromHex(credential.publicKey)), owner));
        if (!credential)
            return { owner, weight };
        const { rpId } = credential;
        return { owner: fromWebAuthnP256(credential, { getFn, rpId }), weight };
    });
    const { salt, threshold } = config;
    const version = BigInt(config.version);
    const account = version === 0n
        ? fromConfig({ owners, salt, threshold })
        : fromConfig({ address, owners, salt, threshold, version });
    if (!Address.isEqual(account.address, address))
        throw new AddressMismatchError({ address, derived: account.address });
    return account;
}
/** Instantiates an Account. */
export function from(parameters) {
    const { access } = parameters;
    if (access)
        return fromAccessKey(parameters);
    return fromRoot(parameters);
}
/**
 * Instantiates an Account from a headless WebAuthn credential (P256 private key).
 *
 * @example
 * ```ts
 * import { Account } from 'viem/tempo'
 *
 * const account = Account.fromHeadlessWebAuthn('0x...')
 * ```
 *
 * @param privateKey P256 private key.
 * @returns Account.
 */
export function fromHeadlessWebAuthn(privateKey, options) {
    const { access, keyAuthorization, keyAuthorizationManager, rpId, origin, internal_version, } = options;
    const publicKey = P256.getPublicKey({ privateKey });
    return from({
        ...(access ? { access, keyAuthorization, keyAuthorizationManager } : {}),
        internal_version,
        keyType: 'webAuthn',
        publicKey,
        async sign({ hash }) {
            const { metadata, payload } = WebAuthnP256.getSignPayload({
                ...options,
                challenge: hash,
                rpId,
                origin,
            });
            const signature = P256.sign({
                payload,
                privateKey,
                hash: true,
            });
            return SignatureEnvelope.serialize({
                metadata,
                signature,
                publicKey,
                type: 'webAuthn',
            });
        },
    });
}
/**
 * Instantiates an Account from a P256 private key.
 *
 * @example
 * ```ts
 * import { Account } from 'viem/tempo'
 *
 * const account = Account.fromP256('0x...')
 * ```
 *
 * @param privateKey P256 private key.
 * @returns Account.
 */
export function fromP256(privateKey, options = {}) {
    const { access, keyAuthorization, keyAuthorizationManager, internal_version, } = options;
    const publicKey = P256.getPublicKey({ privateKey });
    return from({
        ...(access ? { access, keyAuthorization, keyAuthorizationManager } : {}),
        internal_version,
        keyType: 'p256',
        publicKey,
        async sign({ hash }) {
            const signature = P256.sign({ payload: hash, privateKey });
            return SignatureEnvelope.serialize({
                signature,
                publicKey,
                type: 'p256',
            });
        },
    });
}
/**
 * Instantiates an Account from a Secp256k1 private key.
 *
 * @example
 * ```ts
 * import { Account } from 'viem/tempo'
 *
 * const account = Account.fromSecp256k1('0x...')
 * ```
 *
 * @param privateKey Secp256k1 private key.
 * @returns Account.
 */
export function fromSecp256k1(privateKey, options = {}) {
    const { access, keyAuthorization, keyAuthorizationManager, internal_version, } = options;
    const publicKey = Secp256k1.getPublicKey({ privateKey });
    return from({
        ...(access ? { access, keyAuthorization, keyAuthorizationManager } : {}),
        internal_version,
        keyType: 'secp256k1',
        publicKey,
        async sign(parameters) {
            const { hash } = parameters;
            const signature = Secp256k1.sign({ payload: hash, privateKey });
            return Signature.toHex(signature);
        },
    });
}
export function fromConfig(value, options = {}) {
    const configInput = (() => {
        if (typeof value === 'string')
            return undefined;
        if ('upgrade' in value)
            return value.upgrade;
        const { address: _, ...config } = value;
        return config;
    })();
    const config = (() => {
        if (!configInput)
            return undefined;
        const ownerEntries = configInput.owners.map((value) => typeof value === 'string' || 'address' in value
            ? { owner: value, weight: 1 }
            : value);
        const owners = ownerEntries.map(({ owner, weight }) => ({
            owner: typeof owner === 'string' ? owner : owner.address,
            weight,
        }));
        const threshold = configInput.threshold ?? 1;
        if (typeof value !== 'string' && 'upgrade' in value)
            return AccountConfig.fromUpgrade(value.address, { owners, threshold });
        return AccountConfig.from({ ...configInput, owners, threshold });
    })();
    if (typeof value !== 'string' && !('upgrade' in value)) {
        if ((value.address === undefined || value.address === 'infer') &&
            config.version !== 0n)
            throw new Error('An initial account config must have version zero.');
        if (value.address !== undefined &&
            value.address !== 'infer' &&
            config.version === 0n)
            throw new Error('A current account config must have a version.');
    }
    const address = Address.checksum((() => {
        if (typeof value === 'string')
            return value;
        if (value.address === undefined || value.address === 'infer')
            return AccountConfig.getAddress(config);
        return value.address;
    })());
    const ownerAccounts = (() => {
        if (!configInput)
            return [];
        return configInput.owners.flatMap((value) => {
            const owner = typeof value === 'string' || 'address' in value ? value : value.owner;
            return typeof owner === 'string' ? [] : [parseAccount(owner)];
        });
    })();
    if (ownerAccounts.some((owner) => owner.source === 'configurable' || isAccessKeyAccount(owner)))
        throw new Error('Configurable account owners must use primitive signatures.');
    const owners = config?.owners.flatMap(({ owner }) => {
        const account = ownerAccounts.find((account) => Address.isEqual(account.address, owner));
        return account ? [account] : [];
    }) ?? [];
    const account = {
        address,
        config,
        owners,
        publicKey: '0x',
        source: 'configurable',
        type: 'local',
        async sign({ hash }) {
            return SignatureEnvelope.serialize(await signConfigurable(account, { payload: hash }));
        },
        async signMessage({ message }) {
            return await account.sign({ hash: hashMessage(message) });
        },
        async signTransaction(transaction, options) {
            const { serializer = Transaction.serialize } = options ?? {};
            const request = transaction;
            if (request.owner) {
                const owner = parseAccount(request.owner);
                if (owner.type !== 'local')
                    throw new Error('A local owner account is required to approve a configurable account transaction.');
                if (owner.source !== 'root')
                    throw new Error('A Tempo owner account is required to approve a configurable account transaction.');
                const { owner: _, ...ownerRequest } = request;
                return await owner.signTransaction(ownerRequest, options);
            }
            if (owners.length === 0)
                return (await serializer(transaction));
            const presign = {
                ...request,
                signatures: undefined,
                ...(request.feePayerSignature === undefined
                    ? {}
                    : { feePayerSignature: null }),
            };
            const payload = keccak256(await serializer(presign));
            const simulation = request.accountSimulation;
            if (request.from && !Address.isEqual(request.from, address))
                throw new Error('Configurable account does not match the transaction sender.');
            const signature = await signConfigurable(account, {
                config: simulation?.config,
                payload,
                signatures: request.signatures?.map((signature) => parseApproval(signature)),
            });
            return (await serializer(transaction, signature));
        },
        async signTypedData(typedData) {
            return await account.sign({ hash: hashTypedData(typedData) });
        },
    };
    if (options.access)
        return toAccessKey(account, { ...options, access: options.access });
    return account;
}
/** Wraps a configurable account as an access key of a parent account (TIP-1111). */
// biome-ignore lint/correctness/noUnusedVariables: declaration merge
function toAccessKey(account, options) {
    const { access, keyAuthorization } = options;
    const { address: parentAddress } = parseAccount(access);
    const accessKeyAddress = account.address;
    if (Address.isEqual(parentAddress, accessKeyAddress))
        throw new Error('A configurable account cannot be its own access key.');
    if (keyAuthorization &&
        (keyAuthorization.type !== 'configurable' ||
            !Address.isEqual(keyAuthorization.address, accessKeyAddress)))
        throw new Error('Key authorization does not authorize this access key.');
    const keyAuthorizationManager = options.keyAuthorizationManager ??
        (keyAuthorization ? pending(keyAuthorization) : undefined);
    async function sign(parameters) {
        const { hash, raw } = parameters;
        if (raw)
            return await account.sign({ hash });
        const inner = await signConfigurable(account, {
            payload: keccak256(Hex.concat('0x04', hash, parentAddress)),
        });
        return SignatureEnvelope.serialize(SignatureEnvelope.from({
            inner,
            type: 'keychain',
            userAddress: parentAddress,
            version: 'v2',
        }));
    }
    return {
        accessKeyAddress,
        address: Address.checksum(parentAddress),
        delegate: account,
        keyAuthorizationManager,
        keyType: 'configurable',
        publicKey: '0x',
        sign,
        async signAuthorization() {
            throw new Error('A configurable access key cannot sign authorizations.');
        },
        async signMessage({ message }) {
            return await sign({ hash: hashMessage(message) });
        },
        async signTransaction(transaction, options) {
            const { serializer = Transaction.serialize } = options ?? {};
            const request = transaction;
            if (request.owner) {
                const owner = parseAccount(request.owner);
                if (owner.type !== 'local')
                    throw new Error('A local owner account is required to approve a configurable account transaction.');
                if (owner.source !== 'root')
                    throw new Error('A Tempo owner account is required to approve a configurable account transaction.');
                const { owner: _, ...ownerRequest } = request;
                return await owner.signTransaction(ownerRequest, options);
            }
            if (request.from && !Address.isEqual(request.from, parentAddress))
                throw new Error('Access key account does not match the transaction sender.');
            if (account.owners.length === 0)
                return (await serializer(transaction));
            const presign = {
                ...request,
                signatures: undefined,
                ...(request.feePayerSignature === undefined
                    ? {}
                    : { feePayerSignature: null }),
            };
            const payload = keccak256(await serializer(presign));
            const inner = await signConfigurable(account, {
                config: request.accountSimulation?.config,
                payload: keccak256(Hex.concat('0x04', payload, parentAddress)),
                signatures: request.signatures?.map((signature) => parseApproval(signature)),
            });
            const signature = SignatureEnvelope.from({
                inner,
                type: 'keychain',
                userAddress: parentAddress,
                version: 'v2',
            });
            return (await serializer(transaction, signature));
        },
        async signTypedData(typedData) {
            return await sign({ hash: hashTypedData(typedData) });
        },
        async signVoucher(parameters) {
            return await sign({ hash: getVoucherSignPayload(parameters), raw: true });
        },
        source: 'accessKey',
        type: 'local',
    };
}
function isConfigurableAccount(account) {
    return account.source === 'configurable';
}
async function signConfigurable(account, parameters) {
    const { config, payload, signatures: providedSignatures = [] } = parameters;
    const currentConfig = config ?? account.config;
    if (!currentConfig)
        throw new Error('A current account config is required for local signing.');
    const digest = AccountConfig.getSignPayload({
        account: account.address,
        config: currentConfig,
        payload,
    });
    const signatures = [...providedSignatures];
    const signedOwners = new Set();
    let weight = 0;
    for (const signature of providedSignatures) {
        const address = SignatureEnvelope.extractAddress({
            payload: digest,
            signature,
        }).toLowerCase();
        const owner = currentConfig.owners.find((owner) => Address.isEqual(owner.owner, address));
        if (!owner || signedOwners.has(address))
            continue;
        signedOwners.add(address);
        weight += Number(owner.weight);
    }
    const owners = [...currentConfig.owners].sort((a, b) => Number(b.weight) - Number(a.weight) ||
        a.owner.toLowerCase().localeCompare(b.owner.toLowerCase()));
    for (const owner of owners) {
        if (weight >= Number(currentConfig.threshold))
            break;
        const address = owner.owner.toLowerCase();
        if (signedOwners.has(address))
            continue;
        const ownerAccount = account.owners.find((account) => Address.isEqual(account.address, owner.owner));
        if (!ownerAccount)
            continue;
        if (!ownerAccount.sign)
            throw new Error('Configurable account owner account cannot sign.');
        signatures.push(parseApproval(await ownerAccount.sign({ hash: digest })));
        signedOwners.add(address);
        weight += Number(owner.weight);
        if (weight >= Number(currentConfig.threshold))
            break;
    }
    if (weight < Number(currentConfig.threshold))
        throw new Error('Local owners do not meet the threshold.');
    return SignatureEnvelope.from({
        account: account.address,
        config: currentConfig,
        signatures: SignatureEnvelope.sortApprovals({
            account: account.address,
            config: currentConfig,
            payload,
            signatures,
        }),
    });
}
/**
 * Instantiates an Account from a WebAuthn credential.
 *
 * @example
 *
 * ### Create Passkey + Instantiate Account
 *
 * Create a credential with `WebAuthnP256.createCredential` and then instantiate
 * a Viem Account with `Account.fromWebAuthnP256`.
 *
 * It is highly recommended to store the credential's public key in an external store
 * for future use (ie. for future calls to `WebAuthnP256.getCredential`).
 *
 * ```ts
 * import { Account, WebAuthnP256 } from 'viem/tempo'
 * import { publicKeyStore } from './store'
 *
 * // 1. Create credential
 * const credential = await WebAuthnP256.createCredential({ name: 'Example' })
 *
 * // 2. Instantiate account
 * const account = Account.fromWebAuthnP256(credential)
 *
 * // 3. Store public key
 * await publicKeyStore.set(credential.id, credential.publicKey)
 *
 * ```
 *
 * @example
 *
 * ### Get Credential + Instantiate Account
 *
 * Gets a credential from `WebAuthnP256.getCredential` and then instantiates
 * an account with `Account.fromWebAuthnP256`.
 *
 * The `getPublicKey` function is required to fetch the public key paired with the credential
 * from an external store. The public key is required to derive the account's address.
 *
 * ```ts
 * import { Account, WebAuthnP256 } from 'viem/tempo'
 * import { publicKeyStore } from './store'
 *
 * // 1. Get credential
 * const credential = await WebAuthnP256.getCredential({
 *   async getPublicKey(credential) {
 *     // 2. Get public key from external store.
 *     return await publicKeyStore.get(credential.id)
 *   }
 * })
 *
 * // 3. Instantiate account
 * const account = Account.fromWebAuthnP256(credential)
 * ```
 *
 * @param credential WebAuthnP256 credential.
 * @returns Account.
 */
export function fromWebAuthnP256(credential, options = {}) {
    const { id } = credential;
    const publicKey = PublicKey.fromHex(credential.publicKey);
    return from({
        keyType: 'webAuthn',
        publicKey,
        async sign({ hash }) {
            const { metadata, signature } = await WebAuthnP256.sign({
                ...options,
                challenge: hash,
                credentialId: id,
            });
            return SignatureEnvelope.serialize({
                publicKey,
                metadata,
                signature,
                type: 'webAuthn',
            });
        },
    });
}
/**
 * Instantiates an Account from a P256 private key.
 *
 * @example
 * ```ts
 * import { Account } from 'viem/tempo'
 * import { WebCryptoP256 } from 'ox'
 *
 * const keyPair = await WebCryptoP256.createKeyPair()
 *
 * const account = Account.fromWebCryptoP256(keyPair)
 * ```
 *
 * @param keyPair WebCryptoP256 key pair.
 * @returns Account.
 */
export function fromWebCryptoP256(keyPair, options = {}) {
    const { access, keyAuthorization, keyAuthorizationManager, internal_version, } = options;
    const { publicKey, privateKey } = keyPair;
    return from({
        ...(access ? { access, keyAuthorization, keyAuthorizationManager } : {}),
        internal_version,
        keyType: 'p256',
        publicKey,
        async sign({ hash }) {
            const signature = await WebCryptoP256.sign({ payload: hash, privateKey });
            return SignatureEnvelope.serialize({
                signature,
                prehash: true,
                publicKey,
                type: 'p256',
            });
        },
    });
}
export async function signVoucher(account, parameters) {
    const hash = getVoucherSignPayload(parameters);
    if (isAccessKeyAccount(account))
        return account.sign({ hash, raw: true });
    return account.sign({ hash });
}
function getVoucherSignPayload(parameters) {
    const { chainId, channel, cumulativeAmount } = parameters;
    const channelId = typeof channel === 'string'
        ? channel
        : Channel.computeId(channel, {
            chainId,
        });
    return Channel.getVoucherSignPayload({
        chainId,
        channelId,
        cumulativeAmount,
    });
}
function isAccessKeyAccount(account) {
    return account.source === 'accessKey' && 'accessKeyAddress' in account;
}
/** @internal */
export function getKeyAuthorizationSignPayload(account, parameters) {
    const { chainId, expiry, key, limits, scopes, witness } = parameters;
    const { accessKeyAddress, keyType: type } = resolveAccessKey(key);
    if (isAccessKeyAccount(account))
        throw new Error('An access key cannot sign key authorizations.');
    // A configurable account binds its authorization to itself.
    const boundFields = isConfigurableAccount(account)
        ? { account: account.address }
        : {};
    return KeyAuthorization.getSignPayload({
        address: accessKeyAddress,
        chainId,
        expiry,
        limits,
        scopes,
        type,
        witness,
        ...boundFields,
    });
}
export async function signKeyAuthorization(account, parameters) {
    const { chainId, expiry, key, limits, configurable: configurableState, scopes, signatures, witness, } = parameters;
    const { accessKeyAddress, keyType: type } = resolveAccessKey(key);
    const isConfigurable = isConfigurableAccount(account);
    const boundFields = isConfigurable ? { account: account.address } : {};
    const hash = getKeyAuthorizationSignPayload(account, parameters);
    const signature = await (async () => {
        if (isConfigurable) {
            if (!configurableState)
                throw new Error('Configurable account state is required to sign a key authorization.');
            return SignatureEnvelope.serialize(await signConfigurable(account, {
                config: configurableState.config,
                payload: hash,
                signatures: signatures?.map((signature) => parseApproval(signature)),
            }));
        }
        return account.sign({ hash });
    })();
    return KeyAuthorization.from({
        address: accessKeyAddress,
        chainId,
        expiry,
        limits,
        scopes,
        signature: SignatureEnvelope.from(signature),
        type,
        ...(witness ? { witness } : {}),
        ...boundFields,
    });
}
/** @internal */
// biome-ignore lint/correctness/noUnusedVariables: _
function fromBase(parameters) {
    const { keyType = 'secp256k1', parentAddress, source = 'privateKey', internal_version = 'v2', } = parameters;
    const address = parentAddress ?? Address.fromPublicKey(parameters.publicKey);
    const publicKey = PublicKey.toHex(parameters.publicKey, {
        includePrefix: false,
    });
    async function sign({ hash, raw }) {
        if (raw)
            return await parameters.sign({ hash });
        const innerHash = parentAddress && internal_version === 'v2'
            ? keccak256(Hex.concat('0x04', hash, parentAddress))
            : hash;
        const signature = await parameters.sign({ hash: innerHash });
        if (parentAddress)
            return SignatureEnvelope.serialize(SignatureEnvelope.from({
                userAddress: parentAddress,
                inner: SignatureEnvelope.from(signature),
                type: 'keychain',
                version: internal_version,
            }));
        return signature;
    }
    return {
        address: Address.checksum(address),
        keyType,
        sign,
        async signAuthorization(parameters) {
            const { chainId, nonce } = parameters;
            const address = parameters.contractAddress ?? parameters.address;
            const signature = await sign({
                hash: hashAuthorization({ address, chainId, nonce }),
            });
            const envelope = SignatureEnvelope.from(signature);
            if (envelope.type !== 'secp256k1')
                throw new Error('Unsupported signature type. Expected `secp256k1` but got `' +
                    envelope.type +
                    '`.');
            const { r, s, yParity } = envelope.signature;
            return {
                address,
                chainId,
                nonce,
                r: Hex.fromNumber(r, { size: 32 }),
                s: Hex.fromNumber(s, { size: 32 }),
                yParity,
            };
        },
        async signMessage(parameters) {
            const { message } = parameters;
            return await sign({ hash: hashMessage(message) });
        },
        async signTransaction(transaction, options) {
            const { serializer = Transaction.serialize } = options ?? {};
            const presign = (() => {
                if ('feePayerSignature' in transaction && transaction.feePayerSignature)
                    return { ...transaction, feePayerSignature: null };
                return transaction;
            })();
            const payload = keccak256(await serializer(presign));
            // Configurable account (TIP-1107): return this owner's approval, a serialized
            // primitive signature over the owner approval digest, instead of
            // a full serialized transaction. Approvals are combined later in
            // `sendTransaction({ signatures })`.
            const { accountSimulation, from } = transaction;
            if (accountSimulation) {
                if (!from)
                    throw new Error('A configurable account sender is required for signing.');
                const config = AccountConfig.from(accountSimulation.config);
                const { signer = from } = accountSimulation;
                // Owners of a configurable access key (TIP-1111) approve its keychain digest, bound to the sender.
                const digest = AccountConfig.getSignPayload({
                    account: signer,
                    config,
                    payload: Address.isEqual(signer, from)
                        ? payload
                        : keccak256(Hex.concat('0x04', payload, from)),
                });
                return await sign({ hash: digest, raw: true });
            }
            const signature = await sign({ hash: payload });
            const envelope = SignatureEnvelope.from(signature);
            return await serializer(transaction, envelope);
        },
        async signTypedData(typedData) {
            return await sign({ hash: hashTypedData(typedData) });
        },
        async signVoucher(parameters) {
            const hash = getVoucherSignPayload(parameters);
            if (parentAddress)
                return await sign({ hash, raw: true });
            return await sign({ hash });
        },
        publicKey,
        source,
        type: 'local',
    };
}
/** @internal */
// biome-ignore lint/correctness/noUnusedVariables: _
function fromRoot(parameters) {
    const account = fromBase(parameters);
    return {
        ...account,
        source: 'root',
        async signKeyAuthorization(key, parameters) {
            const { chainId, expiry, limits, scopes, witness } = parameters;
            const { accessKeyAddress, keyType: type } = resolveAccessKey(key);
            const signature = await account.sign({
                hash: KeyAuthorization.getSignPayload({
                    address: accessKeyAddress,
                    chainId,
                    expiry,
                    limits,
                    scopes,
                    type,
                    witness,
                }),
            });
            return KeyAuthorization.from({
                address: accessKeyAddress,
                chainId,
                expiry,
                limits,
                scopes,
                signature: SignatureEnvelope.from(signature),
                type,
                ...(witness ? { witness } : {}),
            });
        },
    };
}
// biome-ignore lint/correctness/noUnusedVariables: _
function fromAccessKey(parameters) {
    const { access, keyAuthorization } = parameters;
    const { address: parentAddress } = parseAccount(access);
    const accessKeyAddress = Address.fromPublicKey(parameters.publicKey);
    if (keyAuthorization &&
        !Address.isEqual(keyAuthorization.address, accessKeyAddress))
        throw new Error('Key authorization does not authorize this access key.');
    const keyAuthorizationManager = parameters.keyAuthorizationManager ??
        (keyAuthorization ? pending(keyAuthorization) : undefined);
    const account = fromBase({
        ...parameters,
        keyAuthorizationManager,
        parentAddress,
    });
    // While the manager holds the access key's unregistered authorization, signatures
    // carry it (TIP-1165) so verifiers accept them before the chain registers the key.
    async function preAuthorize(signature) {
        const { internal_version = 'v2' } = parameters;
        if (!keyAuthorization || !keyAuthorizationManager)
            return signature;
        if (internal_version !== 'v2')
            return signature;
        const pending = await keyAuthorizationManager.get({
            address: account.address,
            accessKey: accessKeyAddress,
            chainId: Number(keyAuthorization.chainId),
        });
        if (!pending)
            return signature;
        return SignaturePreAuthorized.wrap({
            keyAuthorization: pending,
            signature: SignatureEnvelope.from(signature),
        });
    }
    return {
        ...account,
        accessKeyAddress,
        keyAuthorizationManager,
        async sign(parameters) {
            const signature = await account.sign(parameters);
            if (parameters.raw)
                return signature;
            return await preAuthorize(signature);
        },
        async signMessage(parameters) {
            return await preAuthorize(await account.signMessage(parameters));
        },
        async signTypedData(typedData) {
            return await preAuthorize(await account.signTypedData(typedData));
        },
        source: 'accessKey',
    };
}
/**
 * Returns a key authorization manager that holds `keyAuthorization` until the
 * chain registers its access key.
 */
function pending(keyAuthorization) {
    let value = keyAuthorization;
    const matches = (key) => Address.isEqual(key.accessKey, keyAuthorization.address) &&
        BigInt(key.chainId) === BigInt(keyAuthorization.chainId);
    return {
        get: (key) => (matches(key) ? value : undefined),
        remove(key) {
            if (matches(key))
                value = undefined;
        },
        set(key, next) {
            if (matches(key))
                value = next;
        },
    };
}
/** @internal */
export function resolveAccessKey(accessKey) {
    if ('accessKeyAddress' in accessKey)
        return {
            accessKeyAddress: accessKey.accessKeyAddress,
            keyType: accessKey.keyType,
        };
    if ('publicKey' in accessKey && accessKey.publicKey)
        return {
            accessKeyAddress: Address.fromPublicKey(PublicKey.fromHex(accessKey.publicKey)),
            keyType: accessKey.type,
        };
    return {
        accessKeyAddress: accessKey.address,
        keyType: accessKey.type,
    };
}
/**
 * Returns a configurable account (TIP-1107) as JSON-safe public values: its
 * address and, when known, its config. {@link deserialize} rebuilds it.
 *
 * @example
 * ```ts
 * import { Account } from 'viem/tempo'
 *
 * localStorage.setItem('account', JSON.stringify(Account.serialize(account)))
 * ```
 *
 * @param account Configurable account.
 * @returns Serialized account.
 */
export function serialize(account) {
    const { address, config } = account;
    return {
        address,
        ...(config ? { config: AccountConfig.toRpc(config) } : {}),
    };
}
/** Thrown when a version-zero config does not derive the account's address. */
export class AddressMismatchError extends BaseError {
    constructor(options) {
        const { address, derived } = options;
        super(`Account config derives ${derived}, not ${address}.`, {
            name: 'Account.AddressMismatchError',
        });
        /** Address the config derives. */
        Object.defineProperty(this, "derived", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.derived = derived;
    }
}
// Export types required for inference.
// biome-ignore lint/performance/noBarrelFile: _
export { 
/** @deprecated */
KeyAuthorization as z_KeyAuthorization, 
/** @deprecated */
SignatureEnvelope as z_SignatureEnvelope, 
/** @deprecated */
TxEnvelopeTempo as z_TxEnvelopeTempo, } from 'ox/tempo';
//# sourceMappingURL=Account.js.map