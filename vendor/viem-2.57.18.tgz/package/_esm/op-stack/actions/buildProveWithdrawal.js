import { getBlock, } from '../../actions/public/getBlock.js';
import { getProof, } from '../../actions/public/getProof.js';
import { fromRlp } from '../../utils/encoding/fromRlp.js';
import { toRlp } from '../../utils/encoding/toRlp.js';
import { keccak256 } from '../../utils/hash/keccak256.js';
import { contracts } from '../contracts.js';
import { getL2BlockNumberAtTimestamp, } from '../utils/getL2BlockNumberAtTimestamp.js';
import { getWithdrawalHashStorageSlot, } from '../utils/getWithdrawalHashStorageSlot.js';
const outputRootProofVersion = '0x0000000000000000000000000000000000000000000000000000000000000000';
/**
 * Builds the transaction that proves a withdrawal was initiated on an L2. Used in the Withdrawal flow.
 *
 * - Docs: https://viem.sh/op-stack/actions/buildProveWithdrawal
 *
 * @param client - Client to use
 * @param parameters - {@link BuildProveWithdrawalParameters}
 * @returns The prove withdraw transaction request. {@link BuildProveWithdrawalReturnType}
 *
 * @example
 * import { createPublicClient, http } from 'viem'
 * import { optimism } from 'viem/chains'
 * import { buildProveWithdrawal } from 'viem/op-stack'
 *
 * const publicClientL2 = createPublicClient({
 *   chain: optimism,
 *   transport: http(),
 * })
 *
 * const args = await buildProveWithdrawal(publicClientL2, {
 *   output: { ... },
 *   withdrawal: { ... },
 * })
 */
export async function buildProveWithdrawal(client, args) {
    const { account, chain = client.chain, game, output, withdrawal } = args;
    const { withdrawalHash } = withdrawal;
    const { l2BlockNumber, usesSuperRoots } = game ?? output;
    const blockNumber = usesSuperRoots
        ? await getL2BlockNumberAtTimestamp(client, {
            timestamp: l2BlockNumber,
        })
        : l2BlockNumber;
    const slot = getWithdrawalHashStorageSlot({ withdrawalHash });
    const [proof, block] = await Promise.all([
        getProof(client, {
            address: contracts.l2ToL1MessagePasser.address,
            storageKeys: [slot],
            blockNumber,
        }),
        getBlock(client, {
            blockNumber,
        }),
    ]);
    if (usesSuperRoots && block.timestamp !== l2BlockNumber)
        throw new Error(`L2 block timestamp ${block.timestamp} does not match dispute game timestamp ${l2BlockNumber}.`);
    return {
        account,
        l2OutputIndex: game?.index ?? output?.outputIndex,
        outputRootProof: {
            latestBlockhash: block.hash,
            messagePasserStorageRoot: proof.storageHash,
            stateRoot: block.stateRoot,
            version: outputRootProofVersion,
        },
        targetChain: chain,
        withdrawalProof: maybeAddProofNode(keccak256(slot), proof.storageProof[0].proof),
        withdrawal,
    };
}
/** @internal */
export function maybeAddProofNode(key, proof) {
    const lastProofRlp = proof[proof.length - 1];
    const lastProof = fromRlp(lastProofRlp);
    if (lastProof.length !== 17)
        return proof;
    const modifiedProof = [...proof];
    for (const item of lastProof) {
        // Find any nodes located inside of the branch node.
        if (!Array.isArray(item))
            continue;
        // Check if the key inside the node matches the key we're looking for. We remove the first
        // two characters (0x) and then we remove one more character (the first nibble) since this
        // is the identifier for the type of node we're looking at. In this case we don't actually
        // care what type of node it is because a branch node would only ever be the final proof
        // element if (1) it includes the leaf node we're looking for or (2) it stores the value
        // within itself. If (1) then this logic will work, if (2) then this won't find anything
        // and we won't append any proof elements, which is exactly what we would want.
        const suffix = item[0].slice(3);
        if (typeof suffix !== 'string' || !key.endsWith(suffix))
            continue;
        modifiedProof.push(toRlp(item));
    }
    return modifiedProof;
}
//# sourceMappingURL=buildProveWithdrawal.js.map